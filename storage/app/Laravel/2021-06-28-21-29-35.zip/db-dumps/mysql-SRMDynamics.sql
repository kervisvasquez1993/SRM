
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `archivados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `archivados` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pivot_tarea_proveeder_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `archivados_pivot_tarea_proveeder_id_foreign` (`pivot_tarea_proveeder_id`),
  CONSTRAINT `archivados_pivot_tarea_proveeder_id_foreign` FOREIGN KEY (`pivot_tarea_proveeder_id`) REFERENCES `pivot_tarea_proveeders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `archivados` WRITE;
/*!40000 ALTER TABLE `archivados` DISABLE KEYS */;
INSERT INTO `archivados` VALUES (1,1,'2021-06-28 19:05:32','2021-06-28 19:05:32'),(2,3,'2021-06-28 19:12:08','2021-06-28 19:12:08');
/*!40000 ALTER TABLE `archivados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `artes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pivot_tarea_proveeder_id` bigint unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creacion_fichas` enum('sin_inicializar','en_proceso','finalizado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sin_inicializar',
  `validacion_fichas` enum('sin_inicializar','en_proceso','finalizado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sin_inicializar',
  `creacion_boceto` enum('sin_inicializar','en_proceso','finalizado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sin_inicializar',
  `validacion_boceto` enum('sin_inicializar','en_proceso','finalizado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sin_inicializar',
  `confirmacion_proveedor` enum('sin_inicializar','en_proceso','finalizado') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sin_inicializar',
  `fecha_fin` timestamp NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `artes_pivot_tarea_proveeder_id_foreign` (`pivot_tarea_proveeder_id`),
  CONSTRAINT `artes_pivot_tarea_proveeder_id_foreign` FOREIGN KEY (`pivot_tarea_proveeder_id`) REFERENCES `pivot_tarea_proveeders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `artes` WRITE;
/*!40000 ALTER TABLE `artes` DISABLE KEYS */;
INSERT INTO `artes` VALUES (1,1,'test','sin_inicializar','sin_inicializar','sin_inicializar','sin_inicializar','sin_inicializar','2021-06-28 15:01:37',NULL,'2021-06-28 15:01:37','2021-06-28 15:01:37'),(2,2,'test','sin_inicializar','sin_inicializar','sin_inicializar','sin_inicializar','sin_inicializar','2021-06-28 18:12:01',NULL,'2021-06-28 18:12:01','2021-06-28 18:12:01'),(3,3,'test','sin_inicializar','sin_inicializar','sin_inicializar','sin_inicializar','sin_inicializar','2021-06-28 18:32:21',NULL,'2021-06-28 18:32:21','2021-06-28 18:32:21');
/*!40000 ALTER TABLE `artes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bocetos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bocetos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `arte_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bocetos_arte_id_foreign` (`arte_id`),
  KEY `bocetos_user_id_foreign` (`user_id`),
  CONSTRAINT `bocetos_arte_id_foreign` FOREIGN KEY (`arte_id`) REFERENCES `artes` (`id`),
  CONSTRAINT `bocetos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bocetos` WRITE;
/*!40000 ALTER TABLE `bocetos` DISABLE KEYS */;
/*!40000 ALTER TABLE `bocetos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pivot_tarea_proveeder_id` bigint unsigned NOT NULL,
  `item` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `registro_salud` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad_ctns` double NOT NULL,
  `price` double NOT NULL,
  `total` double NOT NULL,
  `comprador` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compras_pivot_tarea_proveeder_id_foreign` (`pivot_tarea_proveeder_id`),
  CONSTRAINT `compras_pivot_tarea_proveeder_id_foreign` FOREIGN KEY (`pivot_tarea_proveeder_id`) REFERENCES `pivot_tarea_proveeders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
INSERT INTO `compras` VALUES (1,1,'PT-PM-100C ','MAXAM PREMIUM CHARCOAL TOOTHPASTE 100 GRAMS','PC-E-007.555-VE ',425,1,11,1,NULL,'2021-06-28 15:01:17','2021-06-28 15:01:17'),(2,1,'PT-PM-100M ','MAXAM PREMIUM DOUBLE MINT TOOTHPASTE 100 GRAMS','PC-E-007.554-VE',424,2,10,1,NULL,'2021-06-28 15:01:17','2021-06-28 15:01:17'),(3,1,'PT-PM-100S ','MAXAM PREMIUM SENSITIVE TOOTHPASTE 100 GRAMS','PC-E-007.551-VE',426,1,1,1,NULL,'2021-06-28 15:01:17','2021-06-28 15:01:17'),(4,1,'PT-PM-100W ','MAXAM PREMIUM WHITENING TOOTHPASTE 100 GRAMS:','PC-E-007.550-VE',427,1,1,1,NULL,'2021-06-28 15:01:17','2021-06-28 15:01:17'),(5,1,'PT-C130TC  ','MAXAM MULTI ACTION 130GR, 3 COLORS STRIPE:','PC-E-007.552-VE ',321,1,1,1,NULL,'2021-06-28 15:01:17','2021-06-28 15:01:17'),(6,2,'PT-PM-100C ','MAXAM PREMIUM CHARCOAL TOOTHPASTE 100 GRAMS','PC-E-007.555-VE ',425,1,11,1,NULL,'2021-06-28 18:11:48','2021-06-28 18:11:48'),(7,2,'PT-PM-100M ','MAXAM PREMIUM DOUBLE MINT TOOTHPASTE 100 GRAMS','PC-E-007.554-VE',424,2,10,1,NULL,'2021-06-28 18:11:48','2021-06-28 18:11:48'),(8,2,'PT-PM-100S ','MAXAM PREMIUM SENSITIVE TOOTHPASTE 100 GRAMS','PC-E-007.551-VE',426,1,1,1,NULL,'2021-06-28 18:11:48','2021-06-28 18:11:48'),(9,2,'PT-PM-100W ','MAXAM PREMIUM WHITENING TOOTHPASTE 100 GRAMS:','PC-E-007.550-VE',427,1,1,1,NULL,'2021-06-28 18:11:48','2021-06-28 18:11:48'),(10,2,'PT-C130TC  ','MAXAM MULTI ACTION 130GR, 3 COLORS STRIPE:','PC-E-007.552-VE ',321,1,1,1,NULL,'2021-06-28 18:11:48','2021-06-28 18:11:48'),(11,3,'PT-PM-100C ','MAXAM PREMIUM CHARCOAL TOOTHPASTE 100 GRAMS','PC-E-007.555-VE ',425,1,11,3,NULL,'2021-06-28 18:12:51','2021-06-28 18:12:51'),(12,3,'PT-PM-100M ','MAXAM PREMIUM DOUBLE MINT TOOTHPASTE 100 GRAMS','PC-E-007.554-VE',424,2,10,3,NULL,'2021-06-28 18:12:51','2021-06-28 18:12:51'),(13,3,'PT-PM-100S ','MAXAM PREMIUM SENSITIVE TOOTHPASTE 100 GRAMS','PC-E-007.551-VE',426,1,1,3,NULL,'2021-06-28 18:12:51','2021-06-28 18:12:51'),(14,3,'PT-PM-100W ','MAXAM PREMIUM WHITENING TOOTHPASTE 100 GRAMS:','PC-E-007.550-VE',427,1,1,3,NULL,'2021-06-28 18:12:51','2021-06-28 18:12:51'),(15,3,'PT-C130TC  ','MAXAM MULTI ACTION 130GR, 3 COLORS STRIPE:','PC-E-007.552-VE ',321,1,1,3,NULL,'2021-06-28 18:12:51','2021-06-28 18:12:51');
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `confirmacion_proveedors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `confirmacion_proveedors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `arte_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `confirmacion_proveedors_arte_id_foreign` (`arte_id`),
  KEY `confirmacion_proveedors_user_id_foreign` (`user_id`),
  CONSTRAINT `confirmacion_proveedors_arte_id_foreign` FOREIGN KEY (`arte_id`) REFERENCES `artes` (`id`),
  CONSTRAINT `confirmacion_proveedors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `confirmacion_proveedors` WRITE;
/*!40000 ALTER TABLE `confirmacion_proveedors` DISABLE KEYS */;
/*!40000 ALTER TABLE `confirmacion_proveedors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `countries` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `unico_id` int NOT NULL,
  `proveedor_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `countries_proveedor_id_foreign` (`proveedor_id`),
  CONSTRAINT `countries_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedors` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `estatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estatus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `estatus` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `estatus` WRITE;
/*!40000 ALTER TABLE `estatus` DISABLE KEYS */;
/*!40000 ALTER TABLE `estatus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fichas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fichas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `arte_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fichas_arte_id_foreign` (`arte_id`),
  KEY `fichas_user_id_foreign` (`user_id`),
  CONSTRAINT `fichas_arte_id_foreign` FOREIGN KEY (`arte_id`) REFERENCES `artes` (`id`),
  CONSTRAINT `fichas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fichas` WRITE;
/*!40000 ALTER TABLE `fichas` DISABLE KEYS */;
/*!40000 ALTER TABLE `fichas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `filter_produccion_transitos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filter_produccion_transitos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `proveedor_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `produccion_transitos_id` bigint unsigned NOT NULL,
  `pivot_tarea_proveedor_id` bigint unsigned NOT NULL,
  `code_unit` int NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `filter_produccion_transitos_proveedor_id_foreign` (`proveedor_id`),
  KEY `filter_produccion_transitos_user_id_foreign` (`user_id`),
  KEY `filter_produccion_transitos_produccion_transitos_id_foreign` (`produccion_transitos_id`),
  KEY `filter_produccion_transitos_pivot_tarea_proveedor_id_foreign` (`pivot_tarea_proveedor_id`),
  CONSTRAINT `filter_produccion_transitos_pivot_tarea_proveedor_id_foreign` FOREIGN KEY (`pivot_tarea_proveedor_id`) REFERENCES `pivot_tarea_proveeders` (`id`),
  CONSTRAINT `filter_produccion_transitos_produccion_transitos_id_foreign` FOREIGN KEY (`produccion_transitos_id`) REFERENCES `produccion_transitos` (`id`),
  CONSTRAINT `filter_produccion_transitos_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedors` (`id`),
  CONSTRAINT `filter_produccion_transitos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `filter_produccion_transitos` WRITE;
/*!40000 ALTER TABLE `filter_produccion_transitos` DISABLE KEYS */;
/*!40000 ALTER TABLE `filter_produccion_transitos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `fin_produccions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fin_produccions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `produccion_transito_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fin_produccions_produccion_transito_id_foreign` (`produccion_transito_id`),
  KEY `fin_produccions_user_id_foreign` (`user_id`),
  CONSTRAINT `fin_produccions_produccion_transito_id_foreign` FOREIGN KEY (`produccion_transito_id`) REFERENCES `produccion_transitos` (`id`),
  CONSTRAINT `fin_produccions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `fin_produccions` WRITE;
/*!40000 ALTER TABLE `fin_produccions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fin_produccions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inicio_produccions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inicio_produccions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `produccion_transito_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inicio_produccions_produccion_transito_id_foreign` (`produccion_transito_id`),
  KEY `inicio_produccions_user_id_foreign` (`user_id`),
  CONSTRAINT `inicio_produccions_produccion_transito_id_foreign` FOREIGN KEY (`produccion_transito_id`) REFERENCES `produccion_transitos` (`id`),
  CONSTRAINT `inicio_produccions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inicio_produccions` WRITE;
/*!40000 ALTER TABLE `inicio_produccions` DISABLE KEYS */;
/*!40000 ALTER TABLE `inicio_produccions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inicios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inicios` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inicios` WRITE;
/*!40000 ALTER TABLE `inicios` DISABLE KEYS */;
/*!40000 ALTER TABLE `inicios` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inspeccion_cargas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inspeccion_cargas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `recepcion_reclamo_devolucion_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspeccion_cargas_recepcion_reclamo_devolucion_id_foreign` (`recepcion_reclamo_devolucion_id`),
  KEY `inspeccion_cargas_user_id_foreign` (`user_id`),
  CONSTRAINT `inspeccion_cargas_recepcion_reclamo_devolucion_id_foreign` FOREIGN KEY (`recepcion_reclamo_devolucion_id`) REFERENCES `recepcion_reclamo_devolucions` (`id`),
  CONSTRAINT `inspeccion_cargas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inspeccion_cargas` WRITE;
/*!40000 ALTER TABLE `inspeccion_cargas` DISABLE KEYS */;
/*!40000 ALTER TABLE `inspeccion_cargas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2021_02_22_222106_create_tareas_table',1),(5,'2021_02_22_224832_create_proveedors_table',1),(6,'2021_02_22_224915_create_estatus_table',1),(7,'2021_02_22_224915_create_pivot_tarea_proveeders_table',1),(8,'2021_02_22_224916_create_artes_table',1),(9,'2021_02_23_180200_create_productos_table',1),(10,'2021_02_23_192650_create_compras_table',1),(11,'2021_02_23_202047_create_confirmacion_proveedors_table',1),(12,'2021_02_24_002905_create_fichas_table',1),(13,'2021_02_24_003351_create_validacion_fichas_table',1),(14,'2021_02_24_004812_create_bocetos_table',1),(15,'2021_02_24_004826_create_validacion_bocetos_table',1),(16,'2021_02_24_010605_create_produccion_transitos_table',1),(17,'2021_02_24_012424_create_inicio_produccions_table',1),(18,'2021_02_24_012438_create_fin_produccions_table',1),(19,'2021_02_24_012456_create_pago_anticipados_table',1),(20,'2021_02_24_012456_create_pago_balances_table',1),(21,'2021_02_24_012538_create_transito_nacionalizacions_table',1),(22,'2021_03_08_123354_create_recepcion_reclamo_devolucions_table',1),(23,'2021_03_08_185645_create_recepcion_mercancias_table',1),(24,'2021_03_08_185702_create_inspeccion_cargas_table',1),(25,'2021_03_08_185723_create_reclamos_devoluciones_table',1),(26,'2021_03_08_191413_create_negociacions_table',1),(27,'2021_05_07_173208_create_product_overviews_table',1),(28,'2021_05_12_163903_create_inicios_table',1),(29,'2021_05_17_124853_create_countries_table',1),(30,'2021_05_17_124853_create_filter_produccion_transitos_table',1),(31,'2021_05_27_221147_create_notifications_table',1),(32,'2021_06_11_185058_create_pagos_table',1),(33,'2021_06_25_124012_create_pivot_files_table',1),(34,'2021_06_28_134528_create_archivados_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `negociacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `negociacions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pivot_tarea_proveeder` bigint unsigned NOT NULL,
  `fecha_fin` timestamp NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `negociacions_pivot_tarea_proveeder_foreign` (`pivot_tarea_proveeder`),
  CONSTRAINT `negociacions_pivot_tarea_proveeder_foreign` FOREIGN KEY (`pivot_tarea_proveeder`) REFERENCES `pivot_tarea_proveeders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `negociacions` WRITE;
/*!40000 ALTER TABLE `negociacions` DISABLE KEYS */;
/*!40000 ALTER TABLE `negociacions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES ('1315a128-a68f-43b4-ac3c-7691c759f3c2','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"El usuario kervis vasquez inicio Producci\\u00f3n con la empresa \'empresa1\' asociado a la tarea \'empresa\'\",\"link\":\"\\/productions?id=3\",\"type\":\"iniciar_produccion\"}',NULL,NULL,'2021-06-28 18:32:21','2021-06-28 18:32:21'),('13eae203-03a8-4149-aedf-b835710a904b','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio Producci\\u00f3n con la empresa \'empresa1\' asociado a la tarea \'empresa\'\",\"link\":\"\\/productions?id=1\",\"type\":\"iniciar_produccion\"}',NULL,NULL,'2021-06-28 15:01:37','2021-06-28 15:01:37'),('175b2a74-a8a2-4471-92d3-5405469114fd','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=3\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:02','2021-06-28 18:55:02'),('17c7f76a-b255-4f89-af3a-7b8593c09e0f','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario: \'kervis vasquez\' cargo via excel informacion de producto a la empresa \'kervis\' asociada a la tarea \'rrr\'\",\"link\":\"\\/negotiation\\/2#products\",\"type\":\"cargar_productos\"}',NULL,NULL,'2021-06-28 18:11:43','2021-06-28 18:11:43'),('1984c5b7-c3a3-46f3-a306-eb1516f49b92','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=3\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:02','2021-06-28 18:55:02'),('22e1f6c4-e0cc-414d-8f99-3172f0ae170f','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario: \'pedro\' cargo via excel informacion de producto a la empresa \'empresa1\' asociada a la tarea \'empresa\'\",\"link\":\"\\/negotiation\\/3#products\",\"type\":\"cargar_productos\"}',NULL,NULL,'2021-06-28 18:12:48','2021-06-28 18:12:48'),('245f86ca-9e93-4299-a3a5-38da86219854','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario: \'kervis vasquez\' cargo via excel informacion de producto a la empresa \'empresa1\' asociada a la tarea \'empresa\'\",\"link\":\"\\/negotiation\\/1#products\",\"type\":\"cargar_productos\"}',NULL,NULL,'2021-06-28 15:01:02','2021-06-28 15:01:02'),('2d9b6172-ac8a-4cd8-867e-57cdabfaafed','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=1\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:36','2021-06-28 18:55:36'),('321a0497-7cc7-4f90-b879-49b519c77b30','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa salio del puerto de origen.\",\"link\":\"\\/claims\\/?id=3\",\"type\":\"salida_puerto_origen\"}',NULL,NULL,'2021-06-28 18:55:02','2021-06-28 18:55:02'),('34108afc-3957-4706-b723-6aada25d3a3c','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario pedro inicio negociaci\\u00f3n con la empresa: empresa1 en la tarea: empresa\",\"link\":\"\\/negotiations?id=3\",\"type\":\"iniciar_negociacion\"}',NULL,NULL,'2021-06-28 18:12:38','2021-06-28 18:12:38'),('382c6a2f-e146-4635-a5b4-d967deef332c','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=3\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:02','2021-06-28 18:55:02'),('3994c148-659e-4a50-a7e5-e057decbd2b4','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El coordinador kervis vasquez asigno la tarea: empresa, al comprador kervis vasquez\",\"link\":\"tasks\\/1\",\"type\":\"tarea_asignada\"}',NULL,NULL,'2021-06-28 15:00:31','2021-06-28 15:00:31'),('42031e64-cda3-4604-9463-c2422a425bb0','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio negociaci\\u00f3n con la empresa: empresa1 en la tarea: empresa\",\"link\":\"\\/negotiations?id=1\",\"type\":\"iniciar_negociacion\"}',NULL,NULL,'2021-06-28 15:00:45','2021-06-28 15:00:45'),('44aeade7-9f23-4cf2-8243-362632e0f6d3','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio Arte con la empresa empresa1\",\"link\":\"\\/arts?id=3\",\"type\":\"iniciar_arte\"}',NULL,NULL,'2021-06-28 18:32:21','2021-06-28 18:32:21'),('49860d90-3c8f-4661-97e6-0ebd75d599bf','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario \'kervis vasquez\' a\\u00f1adi\\u00f3 la empresa \'kervis\' a la tarea \'rrr\'\",\"link\":\"\\/tasks\\/3?providerId=2\",\"type\":\"empresa_agregada\"}',NULL,NULL,'2021-06-28 18:11:20','2021-06-28 18:11:20'),('51468581-94c6-4efa-be34-9e09cfeef9bb','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa kervis asociada a la tarea rrr finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=2\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:05','2021-06-28 18:55:05'),('54a81f5f-5c68-4c7c-b44e-ac2c045e0020','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"El usuario \'kervis vasquez\' agrego Pago Anticipado asociado al proveedor empresa1\",\"link\":\"\\/productions?id=3&tab=payments\",\"type\":\"pago_anticipado\"}',NULL,NULL,'2021-06-28 18:54:58','2021-06-28 18:54:58'),('55c2e62c-c025-4283-95de-2d6b6291e8a4','App\\Notifications\\GeneralNotification','App\\User',5,'{\"text\":\"El usuario kervis vasquez inicio Arte con la empresa empresa1\",\"link\":\"\\/arts?id=1\",\"type\":\"iniciar_arte\"}',NULL,NULL,'2021-06-28 15:01:37','2021-06-28 15:01:37'),('5bb5d296-82ba-4fee-b385-e27923544b2b','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=3\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:01','2021-06-28 18:55:01'),('5c78e224-91c5-45f8-9095-6a052f644bc3','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=3\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:01','2021-06-28 18:55:01'),('5d242988-2d69-4919-b8a0-e32a8c9f26c3','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario \'kervis vasquez\' agrego Pago Anticipado asociado al proveedor empresa1\",\"link\":\"\\/productions?id=3&tab=payments\",\"type\":\"pago_anticipado\"}',NULL,NULL,'2021-06-28 18:54:58','2021-06-28 18:54:58'),('5f0e7d49-9c4f-4b10-b7cd-1e4828baaef8','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario \'kervis vasquez\' agrego Pago Anticipado asociado al proveedor empresa1\",\"link\":\"\\/productions?id=1&tab=payments\",\"type\":\"pago_anticipado\"}',NULL,NULL,'2021-06-28 18:55:33','2021-06-28 18:55:33'),('6e42da6f-50ba-4720-9a4c-40e5ef2fea47','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa kervis asociada a la tarea rrr finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=2\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:06','2021-06-28 18:55:06'),('724adac9-b770-49aa-9b1b-fa502dcec3ce','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=1\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:37','2021-06-28 18:55:37'),('763ae4f0-7944-4d98-b0fb-1a0849c9753e','App\\Notifications\\GeneralNotification','App\\User',5,'{\"text\":\"El usuario kervis vasquez inicio Arte con la empresa empresa1\",\"link\":\"\\/arts?id=3\",\"type\":\"iniciar_arte\"}',NULL,NULL,'2021-06-28 18:32:21','2021-06-28 18:32:21'),('893d6bd2-cc73-43c0-a17a-0927c8d6aa2f','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario: \'kervis vasquez\' cargo via excel informacion de orden de compra a la empresa \'empresa1\' asociada a la tarea \'empresa\'\",\"link\":\"\\/negotiation\\/1#purchases\",\"type\":\"cargar_compras\"}',NULL,NULL,'2021-06-28 15:01:17','2021-06-28 15:01:17'),('92a798fb-9863-47ed-83ee-fa8bc3b6a9a2','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio Arte con la empresa empresa1\",\"link\":\"\\/arts?id=1\",\"type\":\"iniciar_arte\"}',NULL,NULL,'2021-06-28 15:01:37','2021-06-28 15:01:37'),('a3149a2a-8514-4056-a383-618d93dca77e','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio Producci\\u00f3n con la empresa \'empresa1\' asociado a la tarea \'empresa\'\",\"link\":\"\\/productions?id=3\",\"type\":\"iniciar_produccion\"}',NULL,NULL,'2021-06-28 18:32:21','2021-06-28 18:32:21'),('a5079d63-4bad-4a22-95d0-a4cccc3fc5a5','App\\Notifications\\GeneralNotification','App\\User',5,'{\"text\":\"El usuario kervis vasquez inicio Arte con la empresa kervis\",\"link\":\"\\/arts?id=2\",\"type\":\"iniciar_arte\"}',NULL,NULL,'2021-06-28 18:12:01','2021-06-28 18:12:01'),('aebdc720-9de3-470d-b9d8-c16b7afed01c','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=1\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:37','2021-06-28 18:55:37'),('b1b04cd9-b8af-4ed9-a933-eb7b33d75dad','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"El usuario kervis vasquez inicio Arte con la empresa empresa1\",\"link\":\"\\/arts?id=3\",\"type\":\"iniciar_arte\"}',NULL,NULL,'2021-06-28 18:32:21','2021-06-28 18:32:21'),('bd1a4d2b-5c73-44b6-87ee-5dd87575cd0a','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa salio del puerto de origen.\",\"link\":\"\\/claims\\/?id=1\",\"type\":\"salida_puerto_origen\"}',NULL,NULL,'2021-06-28 18:55:37','2021-06-28 18:55:37'),('c17e6a7d-d270-4e97-bd75-49ee0f27266c','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"El coordinador kervis vasquez asigno la tarea: empresa, al comprador pedro\",\"link\":\"tasks\\/2\",\"type\":\"tarea_asignada\"}',NULL,NULL,'2021-06-28 18:10:48','2021-06-28 18:10:48'),('c2655f1d-14ff-482c-ac55-6735a687d52b','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio negociaci\\u00f3n con la empresa: kervis en la tarea: rrr\",\"link\":\"\\/negotiations?id=2\",\"type\":\"iniciar_negociacion\"}',NULL,NULL,'2021-06-28 18:11:22','2021-06-28 18:11:22'),('d6b6b655-75ca-49ee-a1e8-054c2fb29f10','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio Arte con la empresa kervis\",\"link\":\"\\/arts?id=2\",\"type\":\"iniciar_arte\"}',NULL,NULL,'2021-06-28 18:12:01','2021-06-28 18:12:01'),('d7d10037-b9fc-49ad-a73e-61d6019becbe','App\\Notifications\\GeneralNotification','App\\User',3,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa salio del puerto de origen.\",\"link\":\"\\/claims\\/?id=3\",\"type\":\"salida_puerto_origen\"}',NULL,NULL,'2021-06-28 18:55:02','2021-06-28 18:55:02'),('d8d44881-006c-4c54-a115-4446a76f0c00','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario: \'kervis vasquez\' cargo via excel informacion de orden de compra a la empresa \'kervis\' asociada a la tarea \'rrr\'\",\"link\":\"\\/negotiation\\/2#purchases\",\"type\":\"cargar_compras\"}',NULL,NULL,'2021-06-28 18:11:48','2021-06-28 18:11:48'),('e2158fb3-b711-484d-b73d-3e42b22f387c','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa kervis asociada a la tarea rrr salio del puerto de origen.\",\"link\":\"\\/claims\\/?id=2\",\"type\":\"salida_puerto_origen\"}',NULL,NULL,'2021-06-28 18:55:21','2021-06-28 18:55:21'),('e238e383-2d2c-4ea5-b737-9c239d2eb7ae','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario: \'pedro\' cargo via excel informacion de orden de compra a la empresa \'empresa1\' asociada a la tarea \'empresa\'\",\"link\":\"\\/negotiation\\/3#purchases\",\"type\":\"cargar_compras\"}',NULL,NULL,'2021-06-28 18:12:51','2021-06-28 18:12:51'),('e7196e84-50d7-4e39-8a37-452c3a15a267','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario kervis vasquez inicio Producci\\u00f3n con la empresa \'kervis\' asociado a la tarea \'rrr\'\",\"link\":\"\\/productions?id=2\",\"type\":\"iniciar_produccion\"}',NULL,NULL,'2021-06-28 18:12:01','2021-06-28 18:12:01'),('ed81a60a-e4c3-48c8-a31a-a684b0e13e8f','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario \'pedro\' a\\u00f1adi\\u00f3 la empresa \'empresa1\' a la tarea \'empresa\'\",\"link\":\"\\/tasks\\/2?providerId=1\",\"type\":\"empresa_agregada\"}',NULL,NULL,'2021-06-28 18:12:37','2021-06-28 18:12:37'),('eee674e6-81b7-40f6-b12e-27cbc4812b54','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"La empresa empresa1 asociada a la tarea empresa finaliz\\u00f3 producci\\u00f3n.\",\"link\":\"\\/productions?id=3\",\"type\":\"fin_produccion\"}',NULL,NULL,'2021-06-28 18:55:02','2021-06-28 18:55:02'),('f30986c3-304e-41d6-bf21-f54268ef389a','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario \'kervis vasquez\' a\\u00f1adi\\u00f3 la empresa \'empresa1\' a la tarea \'empresa\'\",\"link\":\"\\/tasks\\/1?providerId=1\",\"type\":\"empresa_agregada\"}',NULL,NULL,'2021-06-28 15:00:43','2021-06-28 15:00:43'),('f9a343d1-cb50-42a9-b7b2-9833699abeb0','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario \'kervis vasquez\' agrego Pago Anticipado asociado al proveedor kervis\",\"link\":\"\\/productions?id=2&tab=payments\",\"type\":\"pago_anticipado\"}',NULL,NULL,'2021-06-28 18:55:15','2021-06-28 18:55:15'),('f9c49dee-6925-4fc8-8046-7418a82cb6a1','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El usuario: \'kervis vasquez\' cargo via excel informacion de producto a la empresa \'empresa1\' asociada a la tarea \'empresa\'\",\"link\":\"\\/negotiation\\/1#products\",\"type\":\"cargar_productos\"}',NULL,NULL,'2021-06-28 15:01:10','2021-06-28 15:01:10'),('fa63174f-1761-40ba-b392-1c96ae6abd53','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El coordinador kervis vasquez asigno la tarea: rrr, al comprador kervis vasquez\",\"link\":\"tasks\\/3\",\"type\":\"tarea_asignada\"}',NULL,NULL,'2021-06-28 18:11:03','2021-06-28 18:11:03'),('fd00db83-6fd7-4dc3-acf7-765b0a6139ed','App\\Notifications\\GeneralNotification','App\\User',1,'{\"text\":\"El coordinador kervis vasquez asigno la tarea: empresa, al comprador pedro\",\"link\":\"tasks\\/2\",\"type\":\"tarea_asignada\"}',NULL,NULL,'2021-06-28 18:10:48','2021-06-28 18:10:48');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pago_anticipados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pago_anticipados` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `produccion_transito_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto_pagado` double NOT NULL,
  `file_pago` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_pago` timestamp NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pago_anticipados_produccion_transito_id_foreign` (`produccion_transito_id`),
  KEY `pago_anticipados_user_id_foreign` (`user_id`),
  CONSTRAINT `pago_anticipados_produccion_transito_id_foreign` FOREIGN KEY (`produccion_transito_id`) REFERENCES `produccion_transitos` (`id`),
  CONSTRAINT `pago_anticipados_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pago_anticipados` WRITE;
/*!40000 ALTER TABLE `pago_anticipados` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago_anticipados` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pago_balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pago_balances` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `produccion_transito_id` bigint unsigned NOT NULL,
  `pago_anticipado_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto_total` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_pago` timestamp NOT NULL,
  `file_pago` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pago_completo` tinyint(1) NOT NULL DEFAULT '0',
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pago_balances_produccion_transito_id_foreign` (`produccion_transito_id`),
  KEY `pago_balances_pago_anticipado_id_foreign` (`pago_anticipado_id`),
  KEY `pago_balances_user_id_foreign` (`user_id`),
  CONSTRAINT `pago_balances_pago_anticipado_id_foreign` FOREIGN KEY (`pago_anticipado_id`) REFERENCES `pago_anticipados` (`id`),
  CONSTRAINT `pago_balances_produccion_transito_id_foreign` FOREIGN KEY (`produccion_transito_id`) REFERENCES `produccion_transitos` (`id`),
  CONSTRAINT `pago_balances_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pago_balances` WRITE;
/*!40000 ALTER TABLE `pago_balances` DISABLE KEYS */;
/*!40000 ALTER TABLE `pago_balances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `produccion_transito_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` double NOT NULL,
  `url_archivo_factura` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha` date NOT NULL,
  `tipo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pagos_produccion_transito_id_foreign` (`produccion_transito_id`),
  KEY `pagos_user_id_foreign` (`user_id`),
  CONSTRAINT `pagos_produccion_transito_id_foreign` FOREIGN KEY (`produccion_transito_id`) REFERENCES `produccion_transitos` (`id`),
  CONSTRAINT `pagos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,3,1,'prueba1',24,'#','2021-06-22','Pago Anticipado',NULL,'2021-06-28 18:54:58','2021-06-28 18:54:58'),(2,2,1,'sdsds',24,'#','2021-06-22','Pago Anticipado',NULL,'2021-06-28 18:55:15','2021-06-28 18:55:15'),(3,1,1,'prueba1',24,'#','2021-06-22','Pago Anticipado',NULL,'2021-06-28 18:55:33','2021-06-28 18:55:33');
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `perfils`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `perfils` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `biografia` text COLLATE utf8mb4_unicode_ci,
  `imagen` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `perfils_user_id_foreign` (`user_id`),
  CONSTRAINT `perfils_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `perfils` WRITE;
/*!40000 ALTER TABLE `perfils` DISABLE KEYS */;
/*!40000 ALTER TABLE `perfils` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pivot_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pivot_files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pivot_tarea_proveeder_id` bigint unsigned NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pivot_files_pivot_tarea_proveeder_id_foreign` (`pivot_tarea_proveeder_id`),
  CONSTRAINT `pivot_files_pivot_tarea_proveeder_id_foreign` FOREIGN KEY (`pivot_tarea_proveeder_id`) REFERENCES `pivot_tarea_proveeders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pivot_files` WRITE;
/*!40000 ALTER TABLE `pivot_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `pivot_files` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pivot_tarea_proveeders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pivot_tarea_proveeders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tarea_id` bigint unsigned NOT NULL,
  `proveedor_id` bigint unsigned NOT NULL,
  `iniciar_negociacion` tinyint(1) NOT NULL DEFAULT '0',
  `iniciar_arte` tinyint(1) NOT NULL DEFAULT '0',
  `iniciar_produccion` tinyint(1) NOT NULL DEFAULT '0',
  `compra_po` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `codigo_comprador` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_terms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hs_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `incoterms` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_time` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pivot_tarea_proveeders_tarea_id_foreign` (`tarea_id`),
  KEY `pivot_tarea_proveeders_proveedor_id_foreign` (`proveedor_id`),
  CONSTRAINT `pivot_tarea_proveeders_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedors` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pivot_tarea_proveeders_tarea_id_foreign` FOREIGN KEY (`tarea_id`) REFERENCES `tareas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pivot_tarea_proveeders` WRITE;
/*!40000 ALTER TABLE `pivot_tarea_proveeders` DISABLE KEYS */;
INSERT INTO `pivot_tarea_proveeders` VALUES (1,1,1,1,1,1,'123456',NULL,NULL,NULL,NULL,NULL,NULL,'2021-06-28 15:00:43','2021-06-28 15:01:37'),(2,3,2,1,1,1,'123456789',NULL,NULL,NULL,NULL,NULL,NULL,'2021-06-28 18:11:20','2021-06-28 18:12:01'),(3,2,1,1,1,1,'123456',NULL,NULL,NULL,NULL,NULL,NULL,'2021-06-28 18:12:37','2021-06-28 18:32:21');
/*!40000 ALTER TABLE `pivot_tarea_proveeders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `produccion_transitos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `produccion_transitos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pivot_tarea_proveeder_id` bigint unsigned NOT NULL,
  `inicio_produccion` tinyint(1) NOT NULL DEFAULT '0',
  `fin_produccion` tinyint(1) NOT NULL DEFAULT '0',
  `transito_nacionalizacion` tinyint(1) NOT NULL DEFAULT '0',
  `salida_puero_origen` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `produccion_transitos_pivot_tarea_proveeder_id_foreign` (`pivot_tarea_proveeder_id`),
  CONSTRAINT `produccion_transitos_pivot_tarea_proveeder_id_foreign` FOREIGN KEY (`pivot_tarea_proveeder_id`) REFERENCES `pivot_tarea_proveeders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `produccion_transitos` WRITE;
/*!40000 ALTER TABLE `produccion_transitos` DISABLE KEYS */;
INSERT INTO `produccion_transitos` VALUES (1,1,1,1,1,1,NULL,'2021-06-28 15:01:37','2021-06-28 18:55:37'),(2,2,1,1,1,1,NULL,'2021-06-28 18:12:01','2021-06-28 18:55:21'),(3,3,1,1,1,1,NULL,'2021-06-28 18:32:21','2021-06-28 18:55:02');
/*!40000 ALTER TABLE `produccion_transitos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_overviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_overviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `producto_id` bigint unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_overviews_producto_id_foreign` (`producto_id`),
  CONSTRAINT `product_overviews_producto_id_foreign` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_overviews` WRITE;
/*!40000 ALTER TABLE `product_overviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_overviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `pivot_tarea_proveeder_id` bigint unsigned NOT NULL,
  `hs_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `original_product_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shelf_life` double DEFAULT NULL,
  `total_pcs` double DEFAULT NULL,
  `pcs_unit` double DEFAULT NULL,
  `pcs_inner_box` double DEFAULT '0',
  `pcs_ctn` double DEFAULT NULL,
  `ctn_packing_size_l` double DEFAULT NULL,
  `ctn_packing_size_w` double DEFAULT NULL,
  `ctn_packing_size_h` double DEFAULT NULL,
  `cbm` double DEFAULT NULL,
  `n_w_ctn` double DEFAULT NULL,
  `g_w_ctn` double DEFAULT NULL,
  `total_ctn` double DEFAULT NULL,
  `corregido_total_pcs` double DEFAULT NULL,
  `total_cbm` double DEFAULT NULL,
  `total_n_w` double DEFAULT NULL,
  `total_g_w` double DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `productos_pivot_tarea_proveeder_id_foreign` (`pivot_tarea_proveeder_id`),
  CONSTRAINT `productos_pivot_tarea_proveeder_id_foreign` FOREIGN KEY (`pivot_tarea_proveeder_id`) REFERENCES `pivot_tarea_proveeders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,1,'21069069855','2504','Premium Multivitamin 10','Dynamax','Multivitamin','Vit C, zinc, D',36,10000,1,12,180,40,30,30,0.036,12,13,55.555555555556,10080,2,666.66666666667,722.22222222222,NULL,'2021-06-28 15:01:10','2021-06-28 15:01:10'),(2,1,'21069069855','2504','Premium Multivitamin 10','Dynamax','Multivitamin','Vit C, zinc, D',36,1080,1,12,180,40,30,30,0.036,12,13,6,1080,0.216,72,78,NULL,'2021-06-28 15:01:10','2021-06-28 15:01:10'),(3,2,'21069069855','2504','Premium Multivitamin 10','Dynamax','Multivitamin','Vit C, zinc, D',36,10000,1,12,180,40,30,30,0.036,12,13,55.555555555556,10080,2,666.66666666667,722.22222222222,NULL,'2021-06-28 18:11:43','2021-06-28 18:11:43'),(4,2,'21069069855','2504','Premium Multivitamin 10','Dynamax','Multivitamin','Vit C, zinc, D',36,1080,1,12,180,40,30,30,0.036,12,13,6,1080,0.216,72,78,NULL,'2021-06-28 18:11:43','2021-06-28 18:11:43'),(5,3,'21069069855','2504','Premium Multivitamin 10','Dynamax','Multivitamin','Vit C, zinc, D',36,10000,1,12,180,40,30,30,0.036,12,13,55.555555555556,10080,2,666.66666666667,722.22222222222,NULL,'2021-06-28 18:12:47','2021-06-28 18:12:47'),(6,3,'21069069855','2504','Premium Multivitamin 10','Dynamax','Multivitamin','Vit C, zinc, D',36,1080,1,12,180,40,30,30,0.036,12,13,6,1080,0.216,72,78,NULL,'2021-06-28 18:12:47','2021-06-28 18:12:47');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `proveedors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pais` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ciudad` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `distrito` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci,
  `archivos_src` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contacto` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `proveedors_nombre_pais_unique` (`nombre`,`pais`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `proveedors` WRITE;
/*!40000 ALTER TABLE `proveedors` DISABLE KEYS */;
INSERT INTO `proveedors` VALUES (1,'empresa1','VENEZUELA','valencia','fdgdfg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2021-06-28 15:00:43','2021-06-28 15:00:43'),(2,'kervis','VENEZUELA','valencia','fdgdfg','<p>sds</p>',NULL,NULL,NULL,NULL,NULL,NULL,'2021-06-28 18:11:20','2021-06-28 18:11:20');
/*!40000 ALTER TABLE `proveedors` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `recepcion_mercancias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recepcion_mercancias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `recepcion_reclamo_devolucion_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recepcion_mercancias_recepcion_reclamo_devolucion_id_foreign` (`recepcion_reclamo_devolucion_id`),
  KEY `recepcion_mercancias_user_id_foreign` (`user_id`),
  CONSTRAINT `recepcion_mercancias_recepcion_reclamo_devolucion_id_foreign` FOREIGN KEY (`recepcion_reclamo_devolucion_id`) REFERENCES `recepcion_reclamo_devolucions` (`id`),
  CONSTRAINT `recepcion_mercancias_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `recepcion_mercancias` WRITE;
/*!40000 ALTER TABLE `recepcion_mercancias` DISABLE KEYS */;
/*!40000 ALTER TABLE `recepcion_mercancias` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `recepcion_reclamo_devolucions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recepcion_reclamo_devolucions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `produccion_transito_id` bigint unsigned NOT NULL,
  `recepcion_mercancia` tinyint(1) NOT NULL DEFAULT '0',
  `inspeccion_carga` tinyint(1) NOT NULL DEFAULT '0',
  `reclamos_devoluciones` tinyint(1) NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `recepcion_reclamo_devolucions_produccion_transito_id_foreign` (`produccion_transito_id`),
  CONSTRAINT `recepcion_reclamo_devolucions_produccion_transito_id_foreign` FOREIGN KEY (`produccion_transito_id`) REFERENCES `produccion_transitos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `recepcion_reclamo_devolucions` WRITE;
/*!40000 ALTER TABLE `recepcion_reclamo_devolucions` DISABLE KEYS */;
INSERT INTO `recepcion_reclamo_devolucions` VALUES (1,3,1,1,1,NULL,'2021-06-28 18:55:02','2021-06-28 19:12:08'),(2,2,0,0,0,NULL,'2021-06-28 18:55:21','2021-06-28 18:55:21'),(3,1,1,1,1,NULL,'2021-06-28 18:55:37','2021-06-28 19:05:32');
/*!40000 ALTER TABLE `recepcion_reclamo_devolucions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reclamos_devoluciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reclamos_devoluciones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `recepcion_reclamo_devolucion_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reclamos_devoluciones_recepcion_reclamo_devolucion_id_foreign` (`recepcion_reclamo_devolucion_id`),
  KEY `reclamos_devoluciones_user_id_foreign` (`user_id`),
  CONSTRAINT `reclamos_devoluciones_recepcion_reclamo_devolucion_id_foreign` FOREIGN KEY (`recepcion_reclamo_devolucion_id`) REFERENCES `recepcion_reclamo_devolucions` (`id`),
  CONSTRAINT `reclamos_devoluciones_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reclamos_devoluciones` WRITE;
/*!40000 ALTER TABLE `reclamos_devoluciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `reclamos_devoluciones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tareas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tareas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `fecha_fin` date NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tareas_user_id_foreign` (`user_id`),
  CONSTRAINT `tareas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tareas` WRITE;
/*!40000 ALTER TABLE `tareas` DISABLE KEYS */;
INSERT INTO `tareas` VALUES (1,1,1,'empresa','<p>test</p>','2021-06-30',NULL,'2021-06-28 15:00:31','2021-06-28 15:00:31'),(2,1,3,'empresa','<p>sdsdsd</p>','2021-06-30',NULL,'2021-06-28 18:10:48','2021-06-28 18:10:48'),(3,1,1,'rrr','<p>sdsds</p>','2021-06-30',NULL,'2021-06-28 18:11:03','2021-06-28 18:11:03');
/*!40000 ALTER TABLE `tareas` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transito_nacionalizacions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transito_nacionalizacions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `produccion_transito_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transito_nacionalizacions_produccion_transito_id_foreign` (`produccion_transito_id`),
  KEY `transito_nacionalizacions_user_id_foreign` (`user_id`),
  CONSTRAINT `transito_nacionalizacions_produccion_transito_id_foreign` FOREIGN KEY (`produccion_transito_id`) REFERENCES `produccion_transitos` (`id`),
  CONSTRAINT `transito_nacionalizacions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transito_nacionalizacions` WRITE;
/*!40000 ALTER TABLE `transito_nacionalizacions` DISABLE KEYS */;
/*!40000 ALTER TABLE `transito_nacionalizacions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `rol` enum('artes','coordinador','observador','comprador','logistica') COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'coordinador','kervis vasquez','kervisvasquez24@gmail.com',NULL,'$2y$10$SQ8L64irvnEU9RKKJ5JXUO4rVaHo/byaQaMLtXLC65hBfSgxwb6ki',NULL,NULL,'2021-06-28 14:46:54',NULL),(2,'observador','Juan','juan@gmail.com',NULL,'$2y$10$gGd1RSRRozGXmuKSl4fnqugm2lav5P.Q0TCDZ869gajyUecG4XQVu',NULL,NULL,'2021-06-28 14:46:54',NULL),(3,'comprador','pedro','pedro@gmail.com',NULL,'$2y$10$nOc8y7K6zyfLEiBfXpM2v.MQI3KBEnVXZ0PHUfUj.beRouwrbAZka',NULL,NULL,'2021-06-28 14:46:54',NULL),(4,'comprador','jesus','jesus@gmail.com',NULL,'$2y$10$/D.1X2mHE4KA8OUgADguK.WElvlhCH7DM6qtZ14PycFxSS1jO422O',NULL,NULL,'2021-06-28 14:46:54',NULL),(5,'artes','arte','arte@gmail.com',NULL,'$2y$10$IZFtvV0WxRx82H5A6H3CwOx8khi62Gy3cS13nVEpPMrLgG7PZ425e',NULL,NULL,'2021-06-28 14:46:54',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `validacion_bocetos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validacion_bocetos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `arte_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `validacion_bocetos_arte_id_foreign` (`arte_id`),
  KEY `validacion_bocetos_user_id_foreign` (`user_id`),
  CONSTRAINT `validacion_bocetos_arte_id_foreign` FOREIGN KEY (`arte_id`) REFERENCES `artes` (`id`),
  CONSTRAINT `validacion_bocetos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `validacion_bocetos` WRITE;
/*!40000 ALTER TABLE `validacion_bocetos` DISABLE KEYS */;
/*!40000 ALTER TABLE `validacion_bocetos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `validacion_fichas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `validacion_fichas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `arte_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `titulo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `validacion_fichas_arte_id_foreign` (`arte_id`),
  KEY `validacion_fichas_user_id_foreign` (`user_id`),
  CONSTRAINT `validacion_fichas_arte_id_foreign` FOREIGN KEY (`arte_id`) REFERENCES `artes` (`id`),
  CONSTRAINT `validacion_fichas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `validacion_fichas` WRITE;
/*!40000 ALTER TABLE `validacion_fichas` DISABLE KEYS */;
/*!40000 ALTER TABLE `validacion_fichas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

