<template>
        <div class="salida-puerto">
             <a href="#"><strong>Salida de Puerto Origen: </strong></a>
            <div class="center-checkbox">
                        <input type="checkbox" name="">
                        <span class="span">On</span>
                        <span class="span">Off</span>
            </div>
        </div>
</template>
<script>
export default {


}
</script>
