<?php $__env->startSection('content'); ?>
    <h2><?php echo e($proveedoresAprovado); ?></h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/proveedores/index.blade.php ENDPATH**/ ?>