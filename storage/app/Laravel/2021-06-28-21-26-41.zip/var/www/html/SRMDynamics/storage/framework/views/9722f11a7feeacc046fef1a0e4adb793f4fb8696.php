<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('sidebar-filter')->html();
} elseif ($_instance->childHasBeenRendered('a0sOzuC')) {
    $componentId = $_instance->getRenderedChildComponentId('a0sOzuC');
    $componentTag = $_instance->getRenderedChildComponentTagName('a0sOzuC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('a0sOzuC');
} else {
    $response = \Livewire\Livewire::mount('sidebar-filter');
    $html = $response->html();
    $_instance->logRenderedChild('a0sOzuC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/livewire.blade.php ENDPATH**/ ?>