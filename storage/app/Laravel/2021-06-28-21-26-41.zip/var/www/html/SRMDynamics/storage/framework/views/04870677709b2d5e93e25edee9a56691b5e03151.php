 <div class="">
    <a
        class="btn btn-sm btn-outline-primary btn-round" 
        href="<?php echo e(url()->previous()); ?>"
        data-toggle="tooltip" 
        data-placement="left" 
        title="Atras"
    >
    <span class="material-icons mr-2">
        keyboard_backspace
    </span>
        Atras
    </a>
</div><?php /**PATH /var/www/html/SRMDynamics/resources/views/ui/previous.blade.php ENDPATH**/ ?>