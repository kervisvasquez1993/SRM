<div>
    <h1>hola mndo desntro de nav</h1>
</div>
<?php /**PATH /var/www/html/SRMDynamics/resources/views/livewire/nav/show-posts.blade.php ENDPATH**/ ?>