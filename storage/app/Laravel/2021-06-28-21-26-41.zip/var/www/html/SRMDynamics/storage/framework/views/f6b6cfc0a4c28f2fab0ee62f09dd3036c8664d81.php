<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-end">
    <a
        class="btn btn-outline-primary btn-round" 
        href="<?php echo e(url()->previous()); ?>"
        data-toggle="tooltip" 
        data-placement="left" 
        title="Atras"
    >
    <span class="material-icons mr-2">
        keyboard_backspace
    </span>
        Atras
    </a>
</div>

<h4>Editar Pago de Anticipo</h4>

<form novalidate class="m-2" method="POST" action="<?php echo e(route('pago-anticipado.update', [ 'pago_anticipado' => $pagoAnticipado->id, 'id_produccion_transito' => $idProduccionTransito])); ?>">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>

    <div class="row">
        <div class="col-12 col-sm-6 col-md-3 col-lg-3">
            <div class="form-group  <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="bmd-label-floating">Titulo</label>
                <input value="<?php echo e($pagoAnticipado->titulo); ?>" autocomplete="off" name="titulo" type="text" class="form-control">
                <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
        
        <div class="col-12 col-sm-6 col-md-3 col-lg-3">
            <div class="form-group  <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="bmd-label-floating">Total a pagar</label>
                <input value="<?php echo e($pagoAnticipado->monto_total); ?>" autocomplete="off" name="total" type="number" step="0.01" class="form-control">
                <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
        
        <div class="col-12 col-sm-6 col-md-3 col-lg-3">
            <div class="form-group <?php $__errorArgs = ['porcentaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="bmd-label-floating">Porcentaje</label>
                <input value="<?php echo e($pagoAnticipado->porcentaje); ?>" autocomplete="off" name="porcentaje" type="number" step="0.01" max="100" class="form-control">
                
            </div>

        </div>

        
        <div class="col-12 col-sm-6 col-md-3 col-lg-3">
            <div class="form-group  <?php $__errorArgs = ['fecha_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="">Fecha del Pago</label>
                  
                
                
                <input type="date" value="<?php echo e(date('Y-m-d', strtotime($pagoAnticipado->fecha_pago))); ?>" name="fecha_pago" class="form-control" id="fecha_pago">
                
            </div>
            <?php $__errorArgs = ['fecha_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback d-block" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>


    </div>

    <div class="row">

        
        <div class="col-12 col-sm-6 col-md-3 col-lg-3">
            <div class="form-group  <?php $__errorArgs = ['pathfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="bmd-label-floating">Comprobante</label>
                <input value="<?php echo e($pagoAnticipado->file_pago); ?>" autocomplete="off" name="pathfile" type="text" value="path/file" class="form-control">
                <?php $__errorArgs = ['pathfile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>
        
        <div class="col-12 col-sm-6 col-md-3 col-lg-3">
            <div class="form-group  <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="bmd-label-floating">Descripción</label>
                <input value="<?php echo e($pagoAnticipado->descripcion); ?>" autocomplete="off" name="descripcion" type="text" class="form-control">
                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

    </div>

    <div class="d-flex justify-content-center mt-3">
        <button class="btn btn-outline-primary btn-round">
            Guardar
        </button>
    </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/pago-anticipado/edit.blade.php ENDPATH**/ ?>