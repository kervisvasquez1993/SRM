<?php
$fecha_asignada   = $date::parse(date('d-M-Y', strtotime($tarea->fecha_fin)));
if($fecha_asignada > $date::now())
{
  $fecha_restantes  = $fecha_asignada->diffInDays($date::now());
}
else
{
  $fecha_restantes  = 0; 
}
$dias_creacion    = $date::parse(date('d-M-Y', strtotime($tarea->created_at)));
$dias_totales     =  $fecha_asignada->diffInDays($dias_creacion);
if($dias_totales == 0)
{
   $porcentaje = 100;
}
else 
{
  $porcentaje =  round(($fecha_restantes * 100) / $dias_totales);   
}
?><?php /**PATH /var/www/html/SRMDynamics/resources/views/util/calculoFecha.blade.php ENDPATH**/ ?>