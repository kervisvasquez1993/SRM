
<div class="menu">
    <div class="logo">
        <a href="" class="simple-text logo-normal">SRM Dynamics</a>
    </div>
    
    <nav class="">
        <a class="menu-link" href="<?php echo e(route('home')); ?>">
            <i class="material-icons">dashboard</i>
            <span>Inicio</span>
        </a>

        <?php if(Auth::user()->rol == 'coordinador'): ?>
            <a class="menu-link" href="<?php echo e(route('showRegister')); ?>">
                <i class="material-icons">person</i>
                <span>Crear Usuario</span>
            </a>
        <?php endif; ?>
        <?php if(Auth::user()->rol == 'coordinador'): ?>
            <a class="menu-link" href="<?php echo e(route('tareas.index')); ?>">
                <i class="material-icons">task_alt</i>

                <span>Asignacion de Tareas </span>

            </a>
        <?php endif; ?>
        <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?>

            <a class="menu-link" href="<?php echo e(route('perfil.index')); ?>">
                <i class="material-icons">task</i>
                <span>Tareas Asignadas</span>
            </a>

            <a class="menu-link" href=<?php echo e(route('proveedor-negociacion')); ?>>
                <i class="material-icons">business</i>
                <span>Negociaciones</span>
            </a>
        <?php endif; ?>

        <?php if(Auth::user()->rol == 'artes' || Auth::user()->rol == 'coordinador'): ?>

            <a class="menu-link" href="<?php echo e(route('artes.index')); ?>">
                <i class="material-icons">brush</i>
                <span>Artes</span>
            </a>

        <?php endif; ?>

        <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?>

            <a class="menu-link" href="<?php echo e(route('produccion-transito.index')); ?>">
                <i class="material-icons">precision_manufacturing</i>
                <span>Produccion y Transito</span>
            </a>
        <?php endif; ?>

        <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?>
            <a class="menu-link" href="<?php echo e(route('reclamos-devoluciones.index')); ?>">
                <i class="material-icons">production_quantity_limits
                </i>
                <span>Reclamos y Devoluciones</span>
            </a>
        <?php endif; ?>

        <a class="menu-link cerrar-sesion" href="javascript:;" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <i class="material-icons">logout</i>
            <span><?php echo e(__('Logout')); ?></span>
        </a>
    </nav>
</div>

<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST">
    <?php echo csrf_field(); ?>
</form>



<?php /**PATH /var/www/html/SRMDynamics/resources/views/ui/sidebar.blade.php ENDPATH**/ ?>