<script>
    /* window.onload = () => {
        document.addEventListener('click', e => 
        {
            console.log(e.target.parentElement)
        })
    } */


     /*EDITAR CATEGORIA EN VENTANA MODAL*/
    
</script><?php /**PATH /var/www/html/SRMDynamics/resources/views/util/scriptsJs.blade.php ENDPATH**/ ?>