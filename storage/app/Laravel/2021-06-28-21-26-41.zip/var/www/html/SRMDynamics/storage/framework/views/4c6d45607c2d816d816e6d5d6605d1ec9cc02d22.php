<?php $__env->startSection('content'); ?>

<div class="content">
<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">
          <div class="row">
              <?php $__currentLoopData = $perfil->usuario->tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="card">
                <div class="card-header card-header-danger">
                    <h4 class="card-title"><?php echo e($tarea->nombre); ?></h4>
                    <p class="category"><?php echo e($tarea->fecha_fin); ?></p>
                </div>
                <div class="card-body">
                    <?php echo e($tarea->descripcion); ?>

                </div>
                <a href="<?php echo e(route('tareas.show', ['tarea' => $tarea->id])); ?>" class="btn btn-primary ">Editar Perfil</a>
            </div>
            
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            
            
          </div>
        </div>
      <div class="col-md-4">
        <div class="card card-profile">
          <div class="card-avatar">
            <a href="javascript:;">
              <img class="img" src="../assets/img/faces/marc.jpg" />
            </a>
          </div>
          <div class="card-body">
            
            <h4 class="card-title"><?php echo e($perfil->usuario->name); ?></h4>
            <p class="card-description">
              <?php echo e($perfil->biografia); ?>

            </p>
            <a href="<?php echo e(route('perfil.edit', ['perfil' => $perfil->id])); ?>" class="btn btn-primary btn-round">Editar Perfil</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/perfil/show.blade.php ENDPATH**/ ?>