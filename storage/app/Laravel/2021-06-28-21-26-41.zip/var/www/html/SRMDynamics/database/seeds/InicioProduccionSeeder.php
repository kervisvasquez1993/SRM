<?php

use Illuminate\Database\Seeder;

class InicioProduccionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       
    }
}
