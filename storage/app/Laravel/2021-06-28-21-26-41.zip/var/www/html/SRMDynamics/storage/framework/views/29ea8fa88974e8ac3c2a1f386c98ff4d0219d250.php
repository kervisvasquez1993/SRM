
<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="nombre">Nombre<span class="red">*</span></label>
        <input type="text" class="form-control" id="nombre" name="nombre">
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="pais">Pais</label>
        <input type="text" class="form-control" id="pais" name="pais">
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="ciudad">Ciudad</label>
        <input type="text" class="form-control" id="ciudad" name="ciudad">
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="distrito">Distrito</label>
        <input type="text" class="form-control" id="distrito" name="distrito">
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="address">Direccion</label>
        <input type="text" class="form-control" id="address" name="address">
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="contacto">Contacto</label>
        <input type="text" class="form-control" id="contacto" name="contacto">
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="telefono">Teléfono</label>
        <input type="text" class="form-control" id="telefono" name="telefono">
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email">
    </div>
</div>
<div class="form-group">
    <label for="descripcion">Descripcion:</label>
    <textarea class="form-control" id="descripcion" name="descripcion" rows="3" min="25" ></textarea>
</div>




<div class="form-group mb-10">
    <button class="btn btn-sm btn-outline-success btn-round" type="submit">Enviar</button>
    <button class="btn btn-sm btn-outline-warning btn-round" type="reset" name="reset">Limpiar</button>
</div>
<?php /**PATH /var/www/html/SRMDynamics/resources/views/inicio/form.blade.php ENDPATH**/ ?>