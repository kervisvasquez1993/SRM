<?php $__env->startSection('content'); ?>
    <?php if(session('flash')): ?>
        <div class="alert alert-success" id="flash" role="alert">
            <?php echo e(session('flash')); ?>

        </div>
    <?php endif; ?>

    <?php
    //condicional para administrador
    $array_tareas = [];
    $array_users = [];
    $array_paises = [];
    foreach ($aprobados as $value):
        array_push($array_paises, strtoupper($value->proveedor->pais));
        array_push($array_tareas, strtoupper($value->tarea->nombre));
        array_push($array_users, strtoupper($value->tarea->usuario->name));
    endforeach;

    $array_unico_paises = array_unique($array_paises);
    $array_unico_tareas = array_unique($array_tareas);
    $array_users_unico = array_unique($array_users);

    //seccion para comprador

    $array_tarea_comprador = [];
    $array_paises_comprador = [];
    foreach ($userAut->tareas as $tarea):
        array_push($array_tarea_comprador, strtoupper($tarea->nombre));

        foreach ($tarea->proveedor as $proveedor):
            array_push($array_paises_comprador, strtoupper($proveedor->pais));
        endforeach;
    endforeach;
    $array_unico_pais_comprador = array_unique($array_paises_comprador);

    $array_unico_tarea_comprador = array_unique($array_tarea_comprador);
    ?>

    <div class="container">
        <div class="row d-flex">
            <?php if(Auth::user()->rol == 'coordinador'): ?>
                <aside class="">
                    <h6>Compradores</h6>
                    <div class="d-flex flex-wrap">
                        <?php $__currentLoopData = $array_users_unico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="m-2"><input type="checkbox" name="userFilter" value="<?php echo e($item); ?>"
                                    id="<?php echo e($item); ?>"><label for="<?php echo e($item); ?>"><?php echo e($item); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <hr>
                    <h6>Pais</h6>
                    <div class="d-flex flex-wrap">
                        <?php $__currentLoopData = $array_unico_paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="m-2"><input type="checkbox" name="paisesFilter" value="<?php echo e($item); ?>"
                                    id="<?php echo e($item); ?>"><label for="<?php echo e($item); ?>"><?php echo e($item); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <hr>
                    <h6>Tareas</h6>
                    <div class="d-flex flex-wrap">
                        <?php $__currentLoopData = $array_unico_tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="m-2">
                                <input type="checkbox" name="tareas" value="<?php echo e($item); ?>"
                                    id="<?php echo e($item); ?>"><label for="<?php echo e($item); ?>"><?php echo e($item); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </aside>
            <?php endif; ?>

            <?php if(Auth::user()->rol == 'comprador'): ?>
                <aside>
                    <h3>Pais</h3>
                    <div class="d-flex flex-wrap">
                        <?php $__currentLoopData = $array_unico_pais_comprador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="m-2"><input type="checkbox" name="paisesFilter" value="<?php echo e($item); ?>"
                                    id="<?php echo e($item); ?>"><label for="<?php echo e($item); ?>"><?php echo e($item); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <h3>Tareas</h3>
                    <div class="d-flex flex-wrap">
                        <?php $__currentLoopData = $array_unico_tarea_comprador; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="m-2">
                                <input type="checkbox" name="tareas" value="<?php echo e($item); ?>"
                                    id="<?php echo e($item); ?>"><label for="<?php echo e($item); ?>"><?php echo e($item); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </aside>
            <?php endif; ?>

            <?php $__currentLoopData = $aprobados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($value->proveedor->aprovado): ?>
                    <?php if(Auth::user()->name == $value->tarea->usuarios->name || Auth::user()->rol == 'coordinador'): ?>
                        <div class="player <?php echo e(Str::upper($value->proveedor->pais)); ?>  <?php echo e(Str::upper($value->tarea->nombre)); ?> <?php echo e(Str::upper($value->tarea->usuario->name)); ?> "
                            >
                            <?php $__env->startComponent('componentes.cardGeneral'); ?>

                                <?php $__env->slot('titulo'); ?>
                                    <div> Empresa: <?php echo e($value->proveedor->nombre); ?></div>
                                    <div> Tarea: <?php echo e($value->tarea->nombre); ?></div>
                                    <div> Comprador: <?php echo e($value->tarea->usuarios->name); ?></div>

                                    <div class="d-flex">
                                        <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?>
                                            <a href="<?php echo e(route('productos.index', ['id_proveedor' => $value->proveedor->id])); ?>"
                                                type="button" class="btn btn-sm btn-outline-warning btn-round">Agregar Productos
                                            </a>
                                            <?php if($value->proveedor->compra->count() > 0): ?>
                                                <a href="<?php echo e(route('compras.edit', ['compra' => $value->proveedor->compra[0]->id])); ?>"
                                                    type="button" class="btn btn-sm btn-outline-warning btn-round">Editar Orden de
                                                    Compra</a>
                                            <?php elseif($value->proveedor->productos->count() > 0): ?>
                                                <a href="<?php echo e(route('compras.create', ['id_proveedor' => $value->proveedor->id])); ?>"
                                                    type="button" class="btn btn-sm btn-outline-warning btn-round">Agregar Orden de
                                                    Compra</a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                <?php $__env->endSlot(); ?>
                                <?php $__env->slot('bodyCard'); ?>
                                    <div>
                                        <div class="card-header card-header-tabs">
                                            <ul class="nav" data-tabs="tabs">
                                                <li class="btn btn-sm ">
                                                    <a class="nav-link   active show" href="#profile-<?php echo e($value->id); ?>"
                                                        data-toggle="tab">
                                                        <span class="material-icons">
                                                            business
                                                        </span> Detalle de Proveedor
                                                        <div class="ripple-container"></div>
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="btn  btn-sm d-block">
                                                    <a class="nav-link" href="#messages-<?php echo e($value->id); ?>" data-toggle="tab">
                                                        <i class="material-icons">info</i> Detalles de Productos
                                                        <div class="ripple-container"></div>
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="btn  btn-sm d-block">
                                                    <a class="nav-link" href="#settings-<?php echo e($value->id); ?>" data-toggle="tab">
                                                        <i class="material-icons">shopping_cart</i> Detalle De Compra
                                                        <div class="ripple-container"></div>
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="card-body">
                                            <div class="tab-content">
                                                <div class="tab-pane active show" id="profile-<?php echo e($value->id); ?>">
                                                    <table class="table">
                                                        <div class="d-flex w-100  flex-wrap justify-content-between">
                                                            <h4 class="p-4" id="id-proveedor<?php echo e($value->proveedor->id); ?>">
                                                                <strong>País</strong>: <?php echo e($value->proveedor->pais); ?>.
                                                            </h4>
                                                            <h4 class="p-4"><strong>Ciudad</strong>:
                                                                <?php echo e($value->proveedor->ciudad); ?>. </h4>
                                                            <h4 class="p-4"><strong>Distrito</strong>:
                                                                <?php echo e($value->proveedor->distrito); ?>. </h4>
                                                            <h4 class="p-4"><strong>Descripcion</strong>:
                                                                <?php echo e($value->proveedor->descripcion); ?>. </h4>
                                                            <h4 class="p-4"><strong>Direccion</strong>:
                                                                <?php echo e($value->proveedor->address); ?>. </h4>
                                                            <h4 class="p-4"><strong>Contacto</strong>:
                                                                <?php echo e($value->proveedor->contacto); ?>. </h4>
                                                            <h4 class="p-4"><strong>Teléfono</strong>:
                                                                <?php echo e($value->proveedor->telefono); ?>. </h4>
                                                            <h4 class="p-4"><strong>Email</strong>:
                                                                <?php echo e($value->proveedor->email); ?>.
                                                            </h4>

                                                        </div>
                                                    </table>
                                                </div>
                                                <div class="tab-pane" id="messages-<?php echo e($value->id); ?>">
                                                    <table class="table">
                                                        <div class="d-flex w-100  flex-wrap justify-content-between">
                                                            <h4 class="p-4" id=""><strong>Cantidad de Productos</strong>:
                                                                <?php echo e($value->proveedor->productos->count()); ?> </h4>
                                                            <h4 class="p-4" id=""><strong>total NW</strong>:
                                                                <?php echo e($value->proveedor->productos->sum('total_n_w')); ?> </h4>
                                                            <h4 class="p-4" id=""><strong>total GW</strong>:
                                                                <?php echo e($value->proveedor->productos->sum('total_g_w')); ?> </h4>
                                                            <h4 class="p-4" id=""><strong>total CBM</strong>:
                                                                <?php echo e($value->proveedor->productos->sum('total_cbm')); ?> </h4>
                                                            <h4 class="p-4" id=""><strong>total PCS</strong>:
                                                                <?php echo e($value->proveedor->productos->sum('corregido_total_pcs')); ?>

                                                            </h4>
                                                            <h4 class="p-4" id=""><strong>total CTN</strong>:
                                                                <?php echo e($value->proveedor->productos->sum('total_ctn')); ?> </h4>
                                                        </div>

                                                    </table>
                                                </div>
                                                <div class="tab-pane" id="settings-<?php echo e($value->id); ?>">
                                                    <table class="table">

                                                        <?php $__currentLoopData = $value->proveedor->compra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="d-flex w-100  justify-content-between">
                                                                <h5 class="p-3"><strong>Orden de Compra</strong>:
                                                                    <?php echo e($key->orden_compra); ?></h5>
                                                                <h5 class="p-3"><strong>Item</strong>: <?php echo e($key->item); ?> </h5>
                                                                <h5 class="p-3"><strong>Registro Salud</strong>:
                                                                    <?php echo e($key->registro_salud); ?></h5>
                                                                <h5 class="p-3"><strong>Cantidad PCS</strong>:
                                                                    <?php echo e($key->cantidad_pcs); ?> </h5>
                                                                <h5 class="p-3"><strong>Descripción</strong>:
                                                                    <?php echo e($key->descripcion); ?></h5>
                                                                <h5 class="p-3"><strong>Total</strong>: <?php echo e($key->total); ?></h5>

                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php $__env->endSlot(); ?>
                                <?php $__env->slot('contenidoFooter'); ?>
                                    <?php if(Auth::user()->rol == 'coordinador'): ?>
                                        <div class="card-footer">
                                            <div class="d-flex justify-content-between w-100 flex-wrap">
                                                <button id="iniciarArte" data-id="<?php echo e($value->id); ?>"
                                                    data-proveedor="<?php echo e($value->proveedor->id); ?>"
                                                    class=" iniciarArte btn btn-sm btn-online-success btn-round">
                                                    Iniciar Arte
                                                </button>
                                                <button data-id="<?php echo e($value->id); ?>"
                                                    data-proveedor="<?php echo e($value->proveedor->id); ?>"
                                                    class="iniciarProduccion btn btn-sm btn-outline-success btn-round">
                                                    Iniciar Produccion
                                                </button>
                                                <button data-id="<?php echo e($value->id); ?>"
                                                    data-proveedor="<?php echo e($value->proveedor->id); ?>"
                                                    class="iniciarArteProduccion btn btn-sm btn-outline-success btn-round">
                                                    Iniciar Arte y Producción
                                                </button>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                <?php $__env->endSlot(); ?>
                            <?php if (isset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f)): ?>
<?php $component = $__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f; ?>
<?php unset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        let iniciarArte = document.getElementById('eventInit'),
            csrfToken = document.head.querySelector("[name~=csrf-token][content]").content;
        iniciarArte.addEventListener('click', e => {
            let arte = e.target.classList.contains('iniciarArte'),
                produccion = e.target.classList.contains('iniciarProduccion'),
                arteProduccion = e.target.classList.contains('iniciarArteProduccion')

            function initUrl(url) {
                let id = e.target.getAttribute('data-id'),
                    proveedorId = e.target.getAttribute('data-proveedor'),
                    nuevaUrl = `/${url}/${id}/${proveedorId}`
                actualizarRuta(nuevaUrl)
            }

            if (arte) {
                initUrl('arteAprobados')
            }

            if (produccion) {
                initUrl('produccionAprobados')
            }

            if (arteProduccion) {
                initUrl('arteProduccionAprobados')
            }
        })

        function actualizarRuta(url) {
            fetch(url, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                }
            }).then(response => response.json()).then(data => {
                console.log(data)
            })
        }

    </script>

<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.min.js"></script>
    <script type="text/javascript">
        var allCheckboxes = document.querySelectorAll('input[type=checkbox]');
        var allPlayers = Array.from(document.querySelectorAll('.player'));
        var checked = {};

        getChecked('paisesFilter');
        getChecked('tareas');
        getChecked('userFilter');

        Array.prototype.forEach.call(allCheckboxes, function(el) {
            el.addEventListener('change', toggleCheckbox);
        });

        function toggleCheckbox(e) {

            getChecked(e.target.name);
            setVisibility();
        }

        function getChecked(name) {
            checked[name] = Array.from(document.querySelectorAll('input[name=' + name + ']:checked')).map(function(el) {
                return el.value;
            });
        }

        function setVisibility() {

            allPlayers.map(function(el) {
                var paisesFilter = checked.paisesFilter.length ? _.intersection(Array.from(el.classList), checked
                    .paisesFilter).length : true;
                var tareas = checked.tareas.length ? _.intersection(Array.from(el.classList), checked.tareas)
                    .length : true;
                var users = checked.userFilter.length ? _.intersection(Array.from(el.classList), checked.userFilter)
                    .length : true;

                if (paisesFilter && tareas && users) {

                    el.style.display = 'block';
                } else {
                    el.style.display = 'none';
                }
            });
        }

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/proveedor/index.blade.php ENDPATH**/ ?>