<div>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th><strong>ID</strong></th>
                    <th class="th-description">Titulo</th>
                    <th class="th-description">Descripcion</th>
                    <th class="th-description">Fecha</th>
                    <th class="th-description">Usuario</th>    
                    <th></th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                   <tr>
                        <td><?php echo e($incidencia->id); ?></td>
                        <td class="td-name">
                            <?php echo e($incidencia->titulo); ?>

                        </td>
                        <td>
                            <?php echo e($incidencia->descripcion); ?>

                        </td>
                        <td>
                            <?php echo e(date('d-m-Y', strtotime($incidencia->updated_at))); ?>

                        </td>
                        <!--TODO: Configure migrations and model to get and set the user -->
                        <td>
                            <?php echo e($incidencia->user->name); ?>

                        </td>

                        <td class="d-flex">
                            <a
                                
                                href='<?php echo e(route("$route_name.edit", [ $route_entity => $incidencia->id, "rcdId" => $rcdId])); ?>'
                                class="btn btn-outline-primary btn-fab btn-fab-mini btn-round"
                            >
                                <i class="material-icons">mode_edit</i>
                            </a>
    
                            <form 
                                
                                action='<?php echo e(route("$route_name.destroy", [ $route_entity => $incidencia->id, 'rcdId' => $rcdId])); ?>'
                                method="POST" 
                                style="display: contents;"
                            >
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-outline-primary btn-fab btn-fab-mini btn-round ml-2"><i class="material-icons">delete</i></button>
                            </form>
                        </td>

                    </tr>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>

</div><?php /**PATH /var/www/html/SRMDynamics/resources/views/ui/r-reclamos-devoluciones.blade.php ENDPATH**/ ?>