<div class="table-responsive">
    <table class="table table-shopping">
        <thead>
            <tr>
                <th><strong>ID</strong></th>
                <th><strong>Titulo</strong></th>
                <th class="th-description"><strong>Descripción</strong></th>
                <th class="th-description"><strong>Usuario</strong></th>
                <th class="th-description"><strong>Fecha</strong></th>
                <th></th>

            </tr>
        </thead>
        <tbody id="tbody">
            <?php $__currentLoopData = $incidencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incidencia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo e($incidencia->id); ?>">
                    <td class="">
                        <?php echo e($incidencia->id); ?>

                    </td>
                    <td>
                        <?php echo e($incidencia->titulo); ?>

                    </td>
                    <td>
                        <?php echo e($incidencia->descripcion); ?>

                    </td>
                    <td class="">
                        <?php echo e($incidencia->user->name); ?>

                    </td>
                    <td class="">
                        <?php echo e(date('d-m-Y', strtotime($incidencia->updated_at))); ?>

                    </td>

                    <td>
                        <span 
                            id="icon-delete-<?php echo e($incidencia->id); ?>" 
                            onclick="setIncidenciaAttribute(<?php echo e($incidencia); ?>)" 
                            class="material-icons pointer" 
                            data-toggle="modal" 
                            data-target="#deleteModal"
                        >
                            delete_forever
                        </span>
                    </td>

                </tr>

                
                <?php echo $__env->make('ui.borrar-incidencia', array('id' => $incidencia->id, 'path' => $path), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>
</div><?php /**PATH /var/www/html/SRMDynamics/resources/views/ui/incidencias-table.blade.php ENDPATH**/ ?>