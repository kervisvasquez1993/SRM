
<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="nombre">Titulo de la Tarea<span class="red">*</span></label>
        <input type="text" class="form-control <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>">
        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback d-block" role="alert">
            <strong> <?php echo e($message); ?></strong>
          </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="user_id">Comprador:<span class="red">*</span></label>
        <select class="custom-select" id="user_id" name="user_id" >
            <option selected disabled value="">Selecciona...</option>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['user_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback d-block" role="alert">
            <strong> <?php echo e($message); ?></strong>
          </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="form-row">
    <div class="col-md-12 mb-3">
        <label for="fecha_fin">Fecha Finalizacion<span class="red">*</span></label>
        <input type="date" value="<?php echo e(old('fecha_fin')); ?>" id="fecha_fin" name="fecha_fin" class="form-control" pattern="[0-9]{2}-[0-9]{2}-[0-9]{4}">
        <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <span class="invalid-feedback d-block" role="alert">
            <strong> <?php echo e($message); ?></strong>
          </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<div class="form-group">
    <label for="descripcion">Mensaje:<span class="red">*</span></label>
    <textarea class="form-control" id="descripcion" name="descripcion" rows="3" min="25" ></textarea>
</div>



<div class="form-group mb-10">
    <button class="btn btn-sm btn-outline-success btn-round" type="submit">Enviar</button>
    <button class="btn btn-sm btn-outline-warning btn-round" type="reset" name="reset">Limpiar</button>
</div><?php /**PATH /var/www/html/SRMDynamics/resources/views/task/form.blade.php ENDPATH**/ ?>