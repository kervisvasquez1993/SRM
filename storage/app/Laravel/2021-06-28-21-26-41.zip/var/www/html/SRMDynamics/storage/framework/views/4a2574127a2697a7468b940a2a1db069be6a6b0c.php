<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div></div>
        <div class="col-md-12">
            <h2>Notificaciones</h2>
            <ul class="list-group">
                <?php $__currentLoopData = $unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $undreadNotification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(var_dump($undreadNotification->data)); ?>

                    <br>
                    <?php if($undreadNotification->type == "App\Notifications\TareaSent"): ?>
                    <li class="list-group-item">
                        <a href="<?php echo e($undreadNotification->data['link']); ?>"> <?php echo e($undreadNotification->data['text']); ?></a>
                        <form action="<?php echo e(route('notification.read', $undreadNotification->id)); ?>" method="post" class="pull-right">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button class="btn btn-danger btn-xs">X</button>
                        </form>
                    </li>

                    <?php endif; ?>
                     
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
       
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/notification/index.blade.php ENDPATH**/ ?>