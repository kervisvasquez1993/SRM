<div>
    <h4>Lista de Produccion trasito </h4> 
    
    <div class="m-4">
        <div class="d-flex">
            <input wire:model="message" type="text">
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-post')->html();
} elseif ($_instance->childHasBeenRendered('Hd2uetq')) {
    $componentId = $_instance->getRenderedChildComponentId('Hd2uetq');
    $componentTag = $_instance->getRenderedChildComponentTagName('Hd2uetq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Hd2uetq');
} else {
    $response = \Livewire\Livewire::mount('create-post');
    $html = $response->html();
    $_instance->logRenderedChild('Hd2uetq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>

       <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <br>  
          <?php echo e($key); ?>

         <br>
         <br>
       
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
      
               
    </div>
</div>
<?php /**PATH /var/www/html/SRMDynamics/resources/views/livewire/show-posts.blade.php ENDPATH**/ ?>