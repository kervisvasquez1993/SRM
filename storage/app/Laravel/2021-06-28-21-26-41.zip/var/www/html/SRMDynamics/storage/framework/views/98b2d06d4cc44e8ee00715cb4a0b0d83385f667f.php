<div>
        <button class="btn btn-primary">Crear nuevo Post</button>
</div>
<?php /**PATH /var/www/html/SRMDynamics/resources/views/livewire/create-post.blade.php ENDPATH**/ ?>