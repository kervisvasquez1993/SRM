<template>
    <div class="info-status"></div> 
</template>
<script>
export default {
    
}
</script>