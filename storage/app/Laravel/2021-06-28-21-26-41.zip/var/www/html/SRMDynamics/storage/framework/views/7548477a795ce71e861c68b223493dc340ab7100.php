<?php $__env->startSection('content'); ?>

    <div class="d-flex justify-content-between">
        <a
            class="btn btn-outline-primary btn-round"
            href="<?php echo e(route('inspeccion-cargas.create', ['rcdId' => $recepcionReclamoDevolucion->id])); ?>"
        >
            <span class="material-icons mr-2">
                add_circle_outline
            </span>
            Crear
        </a>

        <a
            class="btn btn-outline-primary btn-round" 
            href="<?php echo e(url('/reclamos-devoluciones')); ?>"
            data-toggle="tooltip" 
            data-placement="left" 
            title="Atras"
        >
            <span class="material-icons mr-2">
                keyboard_backspace
            </span>
            Atras
        </a>
    </div>

    <?php if( count($inspeccionesCarga) > 0 ): ?>
        <?php echo $__env->make('ui.r-reclamos-devoluciones', 
            array(
                'incidencias' => $inspeccionesCarga, 
                'rcdId' => $recepcionReclamoDevolucion->id,
                'route_name' => 'inspeccion-cargas', 
                'route_entity' => 'inspeccion_carga'
            )
        , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
       
       <?php echo $__env->make('ui.nada-para-mostrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    <?php endif; ?>

    <?php if(Session::has('message')): ?>
        <div id="toast" class="toast alert alert-<?php echo e(Session::get('class')); ?> alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('message')); ?>


            <span class="material-icons ml-2">
                done_all
            </span>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .toast {
            display: flex;
            justify-content: center;
            position: fixed;
            top: 50%;
            left: 10px;
            right: 10px;
            align-items: center;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/inspeccion-carga/index.blade.php ENDPATH**/ ?>