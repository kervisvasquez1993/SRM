<div class="table-responsive">
    <table class="table table-shopping">
        <thead>
            <tr>
                <th><strong>ID</strong></th>
                <th><strong>Titulo</strong></th>
                <th class="th-description text-center"><strong>Monto Total</strong></th>
                <?php if(Request::is('pago-anticipado')): ?>
                    <th class="th-description"><strong>%</strong></th>
                <?php endif; ?>
                <th class="th-description"><strong>Archivo</strong></th>
                <?php if( Request::is('pago-balance') ): ?>
                    <th class="th-description text-center"><strong>Pago Completo</strong></th>
                <?php endif; ?>
                <th class="th-description"><strong>Fecha Pago</strong></th>
                <th class="th-description"><strong>Descripción</strong></th>
                <th class="th-description"><strong>Usuario</strong></th>
                <th></th>
            </tr>
        </thead>
        <tbody id="tbody">
            <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="<?php echo e($pago->id); ?>">
                    <td class="">
                        <?php echo e($pago->id); ?>

                    </td>
                    <td>
                        <?php echo e($pago->titulo); ?>

                    </td>
                    <td class="text-center">
                        <?php echo e($pago->monto_total); ?>

                    </td>
                    <?php if(Request::is('pago-anticipado')): ?>
                        <td class="">
                            <?php echo e($pago->porcentaje); ?>

                        </td>
                    <?php endif; ?>
                    <td class="">
                        <?php echo e($pago->file_pago); ?>

                    </td>

                    <?php if( Request::is('pago-balance') ): ?>

                        <td class="text-center">

                            <?php if($pago->pago_completo): ?>
                                <span class="material-icons text-success">
                                    check_circle
                                </span>
    
                            <?php else: ?>   
                                <span class="material-icons text-danger">
                                    highlight_off
                                </span>
                            <?php endif; ?>
                        </td>
    
                    <?php endif; ?>
                    <td class="">
                        <?php echo e(date('d-m-Y', strtotime($pago->fecha_pago))); ?>

                    </td>
                    <td class="">
                        <?php echo e($pago->descripcion); ?>

                    </td>
                    <td class="">
                        <?php echo e($pago->user->name); ?>

                    </td>

                    <td class="d-flex">
                        <a href='<?php echo e(route("$route_name.edit", [ $route_entity => $pago->id, "id_produccion_transito" => $produccion_transito->id])); ?>' 
                            class="btn btn-outline-primary btn-fab btn-fab-mini btn-round"
                        >
                            <i class="material-icons">mode_edit</i>
                        </a>

                        <form action='<?php echo e(route("$route_name.destroy", [ $route_entity => $pago->id, 'id_produccion_transito' => $produccion_transito->id])); ?>' method="POST" style="display: contents;">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-primary btn-fab btn-fab-mini btn-round ml-2"><i class="material-icons">delete</i></button>
                        </form>
                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
    </table>

    <?php if(Session::has('message')): ?>
        <div id="toast" class="toast alert alert-<?php echo e(Session::get('class')); ?> alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('message')); ?>


            <span class="material-icons ml-2">
                done_all
            </span>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /var/www/html/SRMDynamics/resources/views/ui/pagos-table.blade.php ENDPATH**/ ?>