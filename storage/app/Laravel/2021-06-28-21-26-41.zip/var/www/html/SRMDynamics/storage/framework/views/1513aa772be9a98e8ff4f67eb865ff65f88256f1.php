<?php $__env->startSection('content'); ?>
    <?php
    $fecha_asignada = $date::parse(date('d-M-Y', strtotime($tarea->fecha_fin)));
    if ($fecha_asignada > $date::now()) {
        $fecha_restantes = $fecha_asignada->diffInDays($date::now());
    } else {
        $fecha_restantes = 0;
    }
    $dias_creacion = $date::parse(date('d-M-Y', strtotime($tarea->created_at)));
    $dias_totales = $fecha_asignada->diffInDays($dias_creacion);
    if ($dias_totales == 0) {
        $porcentaje = 100;
    } else {
        $porcentaje = round(($fecha_restantes * 100) / $dias_totales);
    }
    ?>

    <div class="content">
        <?php if(session('aprobado')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('aprobado')); ?>

            </div>
        <?php endif; ?>
        <div class="container-fluid">
            <div class="row">
                <div class="container-fluid d-flex justify-content-between mb-4">
                    <div>
                        <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?>
                            <a href="#" type="button" class="btn btn-sm btn-outline-primary btn-round"
                                data-id_tarea=<?php echo e($tarea->id); ?> data-toggle="modal" data-target="#abrirmodalEditar">
                                Agregar Empresa
                            </a>
                        <?php endif; ?>
                        <a href="<?php echo e(route('proveedor-negociacion')); ?>" type="button"
                            class="btn btn-sm btn-outline-primary btn-round">
                            <span class="font-weight-bold">
                                Empresas en Negociacion <?php echo e($aprovado->count()); ?>

                            </span>
                        </a>
                    </div>

                    <?php echo $__env->make('ui.previous', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12">

                            <div class="row mb-4">
                                <div class="col-md-6 ml-auto mr-auto text-center">
                                    <h4 class="card-title">
                                        Detalles de Tarea
                                    </h4>
                                </div>
                            </div>

                            <div class="tarea-detalles" data-circulo data-fecha-fin="<?php echo e($tarea->fecha_fin); ?>" data-created-at="<?php echo e($tarea->created_at); ?>">
                                <span class="detalle"><strong>Nombre de Tarea :</strong> <?php echo e($tarea->nombre); ?></span>
                                <span class="detalle"><strong>Fecha de Finalizacion :</strong> <?php echo e(date('d-M-Y', strtotime($tarea->fecha_fin))); ?></span>
                                <span class="detalle"><strong>Días Totales :</strong> <?php echo e($dias_totales); ?> Días</span>
                                <span class="detalle"><strong>Días Restante :</strong> <?php echo e($fecha_restantes); ?> Días restante</span>
                                <span class="detalle"><strong>Finalizacion :</strong> <?php echo e($porcentaje); ?> %</span>
                            </div>

                            

                        </div>
                    </div>
                    <?php echo e($tarea->descripcion); ?>


                    <div class="empresas-titulo">
                        <h4>Empresas asociadas a la Tarea</h4>
                    </div>

                    <?php $__currentLoopData = $noAprovado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proveedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        

                        <?php $__env->startComponent('componentes.cardGeneral'); ?>
                            <?php $__env->slot('titulo'); ?>
                                <div> Nombre Empresa: <?php echo e($proveedor->nombre); ?></div>
                                <div class="d-flex">
                                    <?php if(Auth::user()->rol == 'coordinador' || Auth::user()->rol == 'comprador'): ?>
                                        <form action="<?php echo e(route('negociaciones.update', ['negociar' => $proveedor->id])); ?>"
                                            method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <input type="hidden" name="aprovado" value="1">
                                            <input type="hidden" name="name" value="<?php echo e($proveedor->id); ?>">
                                            <input type="submit" value="Negociar" class="btn btn-sm btn-outline-primary btn-round">
                                        </form>
                                    <?php endif; ?>
                                    
                                    <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?>
                                        <a href="#" type="button" class="btn btn-sm btn-outline-primary btn-round"
                                            data-id_tarea="<?php echo e($proveedor->id); ?>" data-tarea="<?php echo e($proveedor->nombre); ?>"
                                            data-pais="<?php echo e($proveedor->pais); ?>" data-ciudad="<?php echo e($proveedor->ciudad); ?>"
                                            data-distrito="<?php echo e($proveedor->distrito); ?>"
                                            data-direccion="<?php echo e($proveedor->direccion); ?>"
                                            data-contactos="<?php echo e($proveedor->contacto); ?>"
                                            data-telefonos="<?php echo e($proveedor->telefono); ?>" data-email="<?php echo e($proveedor->email); ?>"
                                            data-descripcion="<?php echo e($proveedor->descripcion); ?>" data-toggle="modal"
                                            data-target="#abrirmodalEditarProveedor">
                                            <span class="material-icons">
                                                edit
                                            </span>
                                            Editar
                                        </a>
                                    <?php endif; ?>
                                </div>
                            <?php $__env->endSlot(); ?>
                            <?php $__env->slot('bodyCard'); ?>
                                <h6 class="font-weight-bold">Pais: <?php echo e($proveedor->pais); ?>, Ciudad: <?php echo e($proveedor->ciudad); ?>,
                                    Distrito: <?php echo e($proveedor->distrito); ?> </h6>
                                <div>
                                    <p>
                                        <?php echo e($proveedor->descripcion); ?>

                                    </p>
                                </div>


                            <?php $__env->endSlot(); ?>

                            <?php $__env->slot('contenidoFooter'); ?>
                                <p class="font-weight-bold">Direccion: <?php echo e($proveedor->address); ?></p>
                                <p class="font-weight-bold">Teléfono: <?php echo e($proveedor->telefono); ?></p>
                                <p class="font-weight-bold">Contacto: <?php echo e($proveedor->contacto); ?></p>
                                <p class="font-weight-bold">email: <?php echo e($proveedor->email); ?></p>
                                <p class="font-weight-bold">Contacto: <?php echo e($proveedor->contacto); ?></p>

                            <?php $__env->endSlot(); ?>
                        <?php if (isset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f)): ?>
<?php $component = $__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f; ?>
<?php unset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </div>
            </div>
        </div>
    </div>
    <!--Inicio del modal actualizar-->
    </div>

    <div class="modal fade" id="abrirmodalEditarProveedor" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-primary modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Actualizar Tareas </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <h1>hola</h1>
                        <input type="hidden" id="id_tarea" name="id_tarea" value="">
                        <?php echo $__env->make('inicio.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </form>
                </div> 

            </div>
            <!-- /.modal-content -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startComponent('componentes.formularioModalEdit'); ?>
    <?php $__env->slot('titleForm'); ?>
        <h4>Añadir Nueva Empresa</h4>
    <?php $__env->endSlot(); ?>
    <?php $__env->slot('route'); ?>
        <?php echo e(route('proveedores.store')); ?>

    <?php $__env->endSlot(); ?>
    <?php $__env->slot('method'); ?>
        post
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('BodyForm'); ?>

        <input type="hidden" id="id_tarea" name="id_tarea" value="">
        <h1>hola</h1>
        <?php echo $__env->make('inicio.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginald1f532309cc9192b1ca97ef42a36af59e0eff7c1)): ?>
<?php $component = $__componentOriginald1f532309cc9192b1ca97ef42a36af59e0eff7c1; ?>
<?php unset($__componentOriginald1f532309cc9192b1ca97ef42a36af59e0eff7c1); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .empresas-titulo {
            display: flex;
            justify-content: center;
            margin-top: 1.6em
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/task/show.blade.php ENDPATH**/ ?>