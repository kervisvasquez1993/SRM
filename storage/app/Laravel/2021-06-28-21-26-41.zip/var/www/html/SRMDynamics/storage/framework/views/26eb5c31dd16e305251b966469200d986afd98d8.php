<div class="no-result d-flex justify-content-center align-items-center mt-5">
    <span class="material-icons mr-2">
      search_off
    </span>
    No hay registros para mostrar.
 </div>
<?php /**PATH /var/www/html/SRMDynamics/resources/views/ui/nada-para-mostrar.blade.php ENDPATH**/ ?>