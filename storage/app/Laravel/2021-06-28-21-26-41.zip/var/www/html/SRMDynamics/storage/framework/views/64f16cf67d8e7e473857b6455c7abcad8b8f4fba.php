<?php $__env->startSection('content'); ?>

  <?php echo $__env->make('ui.filter',  array('estatus' => $estatus), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="">
  
    <?php if( count($artes) > 0 ): ?>
      <?php $__currentLoopData = $artes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $arte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
        
        <div id="<?php echo e($arte->id); ?>" class="card" disabled>
          
             <div class="card-header d-flex justify-content-between flex-wrap">
              <h4 class="card-title"><strong class="text-secondary">Tarea: </strong> <span id="arte-name"><?php echo e($arte->nombre); ?></span></h4>
              <h4 class=""> <strong class="text-secondary">Proveedor: </strong> <?php echo e($arte->pivotTable->proveedor->nombre); ?></h4>
              <h4 class=""> <strong class="text-secondary">Fecha Fin: </strong> <?php echo e(date('d-m-Y', strtotime($arte->fecha_fin))); ?></h4>
             </div>
             <hr class="separator">
             <div class="card-body d-flex flex-wrap p-2 m-2">
              <strong class="text-secondary">Estatus: </strong>
              <div class="status d-flex justify-content-between">
                  <span class="mr-3">
                    <strong class="text-secondary pointer-underline">
                      <a  <?php if(Auth::user()->rol == 'artes'): ?>  href="<?php echo e(route('fichas.index', ['arte' => $arte->id])); ?>"  else  href="#" onclick="deshabilitar(this)" <?php endif; ?>>
                        Creación de Fichas <span class="material-icons more-details"> north_east </span>:
                      </a>
                    </strong>
                    <span id="card-ficha-estatus-<?php echo e($arte->id); ?>"><?php echo e($arte->fichasEstatus->estatus); ?></span>
                  </span>

                  <span class="mr-3">
                    <strong class="text-secondary pointer-underline">
                      <a  <?php if(Auth::user()->rol == 'artes'): ?> href="<?php echo e(route('validacion-fichas.index', ['arte' => $arte->id])); ?>"  else { href="#" onclick="deshabilitar(this)" <?php endif; ?>>
                        Validación de Fichas <span class="material-icons more-details"> north_east </span>:
                      </a>
                    </strong> 
                    <span id="card-validacion-ficha-<?php echo e($arte->id); ?>"><?php echo e($arte->validacionFichasEstatus->estatus); ?></span>
                  </span>

                  <span class="mr-3">
                    <strong class="text-secondary pointer-underline">
                      <a  <?php if(Auth::user()->rol == 'artes'): ?>  href="<?php echo e(route('bocetos.index', ['arte' => $arte->id])); ?>"  else  href="#" onclick="deshabilitar(this)"  <?php endif; ?>>
                      
                        Creación de Boceto <span class="material-icons more-details"> north_east </span>:
                      </a>
                    </strong> 
                    <span id="card-boceto-estatus-<?php echo e($arte->id); ?>"><?php echo e($arte->bocetosEstatus->estatus); ?></span>
                  </span>

                  <span class="mr-3">
                    <strong class="text-secondary pointer-underline">
                      <a  <?php if(Auth::user()->rol == 'artes'): ?>  href="<?php echo e(route('validacion-bocetos.index', ['arte' => $arte->id])); ?>"  else  href="#" onclick="deshabilitar(this)"  <?php endif; ?>>
                     
                       Validación de Boceto <span class="material-icons more-details"> north_east </span>:
                      </a> 
                    </strong> 
                    <span id="card-validacion-boceto-<?php echo e($arte->id); ?>"><?php echo e($arte->validacionBocetosEstatus->estatus); ?></span>
                  </span>

                  <span class="mr-3">
                    <strong class="text-secondary pointer-underline">
                      <a  <?php if(Auth::user()->rol == 'artes'): ?> href="<?php echo e(route('confirmacion-proveedor.index', ['arte' => $arte->id])); ?>"  else  href="#" onclick="deshabilitar(this)"  <?php endif; ?> >
                      
                        Confirmación de Proveedor <span class="material-icons more-details"> north_east </span>:
                      </a>
                    </strong> 
                    <span id="card-confirm-proveedor-<?php echo e($arte->id); ?>"><?php echo e($arte->confirmacionProveedorEstatus->estatus); ?></span>
                  </span>
              </div>
             </div>
             <div class="d-flex justify-content-end m-2">
                  <span class="material-icons launch" <?php if(Auth::user()->rol == 'artes'): ?>  onclick="showModal(<?php echo e($arte); ?>, <?php echo e($estatus); ?>)"  data-toggle="modal" data-target="#modal-<?php echo e($arte->id); ?>" <?php endif; ?>>
                    launch
                  </span>
             </div>
        </div>
          
          
          <!-- Modal -->
          <div class="modal fade" id="modal-<?php echo e($arte->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" id="exampleModalLabel">Estatus para: <span id="modal-name-<?php echo e($arte->id); ?>"></span></h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                  
                  
                  <form class="row" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>


                    <div class="form-group  col-md-6">
                        <label for="creacion_ficha">Creacion de Fichas</label>
                        <select name="creacion_ficha" id="creacion_ficha-<?php echo e($arte->id); ?>" class="form-control">
                            <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($item->id); ?>"><?php echo e($item->estatus); ?></option>
                              
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group  col-md-6">
                        <label for="validacion_ficha">Validación de Fichas</label>

                        <select name="validacion_ficha" id="validacion_ficha-<?php echo e($arte->id); ?>" class="form-control">
                          <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('validacion_ficha') == $item->id ? 'selected': ''); ?>><?php echo e($item->estatus); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="creacion_boceto">Creación de Boceto</label>

                        <select name="creacion_boceto" id="creacion_boceto-<?php echo e($arte->id); ?>" class="form-control">
                          <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('creacion_boceto') == $item->id ? 'selected': ''); ?>><?php echo e($item->estatus); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="validacion_boceto">Validación de Boceto</label>

                        <select name="validacion_boceto" id="validacion_boceto-<?php echo e($arte->id); ?>" class="form-control">
                          <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('validacion_boceto') == $item->id ? 'selected': ''); ?>><?php echo e($item->estatus); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group col-md-6">
                        <label for="confirmacion_proveedor">Confirmación de Proveedor</label>

                        <select name="confirmacion_proveedor" id="confirmacion_proveedor-<?php echo e($arte->id); ?>" class="form-control">
                          <?php $__currentLoopData = $estatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->id); ?>" <?php echo e(old('confirmacion_proveedor') == $item->id ? 'selected': ''); ?>><?php echo e($item->estatus); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    

                  </form>

                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary btn-round" data-dismiss="modal">Cerrar</button>
                  <button type="submit" onclick="submit(<?php echo e($arte); ?>, <?php echo e($estatus); ?>)" class="btn btn-outline-primary btn-round">Guardar</button>
                </div>
              </div>
            </div>
          </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
      
      <?php echo $__env->make('ui.nada-para-mostrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <?php endif; ?>
    
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

  <script>
 
 
  /** 
    Display Arte information on modal
  */
  function showModal ( arte, estatus ) {

    const modal = document.getElementById(`modal-${ arte.id }`);

    // Change modal title
    document.getElementById(`modal-name-${ arte.id }`).innerText = arte.nombre;

    // References to the selects in the form
    let optionsCreacionFicha = document.getElementById(`creacion_ficha-${arte.id}`).options;
    let optionsValidFicha = document.getElementById(`validacion_ficha-${arte.id}`).options;
    let optionsCreacionBoceto = document.getElementById(`creacion_boceto-${arte.id}`).options;
    let optionsValidBoceto = document.getElementById(`validacion_boceto-${arte.id}`).options;
    let optionsConfirmProveedor = document.getElementById(`confirmacion_proveedor-${arte.id}`).options;

    estatus.forEach( (item, index) => {
      // Reference to each option in the select
      let optCreationFicha = optionsCreacionFicha[index];
      let optValidFicha = optionsValidFicha[index];
      let optCreacionBoceto = optionsCreacionBoceto[index];
      let optValidBoceto = optionsValidBoceto[index];
      let optConfirmProveedor = optionsConfirmProveedor[index];
      // Select the option depending on the status of the arte entity
      optCreationFicha.selected = item.estatus === document.getElementById(`card-ficha-estatus-${ arte.id }`).innerText;
      optValidFicha.selected = item.estatus === document.getElementById(`card-validacion-ficha-${ arte.id }`).innerText;
      optCreacionBoceto.selected = item.estatus === document.getElementById(`card-boceto-estatus-${ arte.id }`).innerText;
      optValidBoceto.selected = item.estatus === document.getElementById(`card-validacion-boceto-${ arte.id }`).innerText;
      optConfirmProveedor.selected = item.estatus === document.getElementById(`card-confirm-proveedor-${ arte.id }`).innerText;
     
    });
  }

  /** 
    Submit changes on Arte estatus
  */
  function submit( arte, estatus ) {
    // Params to edit 
    const params = {
      creacion_ficha: document.getElementById(`creacion_ficha-${arte.id}`).value,
      validacion_ficha: document.getElementById(`validacion_ficha-${arte.id}`).value,
      creacion_boceto: document.getElementById(`creacion_boceto-${arte.id}`).value,
      validacion_boceto: document.getElementById(`validacion_boceto-${arte.id}`).value,
      confirmacion_proveedor: document.getElementById(`confirmacion_proveedor-${arte.id}`).value
    };


    // Post changes to controller
    axios.post(
      `/artes/${ arte.id }`,
      { params, _method: 'put'}
    ).then( resp => {
      // Response after Arte is edited

      const updatedArte = resp.data;
      
      
      // Hide Modal
      $(`#modal-${arte.id}`).modal('hide')


      const cardUpdated = document.getElementById(`${ arte.id }`);
      const cardStatus = cardUpdated.getElementsByClassName('card-body')[0].children[1];

      // New estatus yto show in the card
      const estCreacionFicha = estatus.find( est => est.id === updatedArte.creacion_fichas );
      const estValidacionFicha = estatus.find( est => est.id === updatedArte.validacion_fichas );
      const estCreacionBoceto = estatus.find( est => est.id === updatedArte.creacion_boceto );
      const estValidacionBoceto = estatus.find( est => est.id === updatedArte.validacion_boceto );
      const estConfirmacionProveedor = estatus.find( est => est.id === updatedArte.confirmacion_proveedor );

      // Update card information
      cardStatus.innerHTML = `
        <span class="mr-3"><strong class="text-secondary">Creación de Fichas:</strong> <span id="card-ficha-estatus-${ arte.id }">${  estCreacionFicha.estatus }</span></span>
        <span class="mr-3"><strong class="text-secondary">Validación de Fichas:</strong> <span id="card-validacion-ficha-${ arte.id }">${ estValidacionFicha.estatus }</span></span>
        <span class="mr-3"><strong class="text-secondary">Creación de Boceto:</strong> <span id="card-boceto-estatus-${ arte.id }">${ estCreacionBoceto.estatus }</span></span>
        <span class="mr-3"><strong class="text-secondary">Validación de Boceto:</strong> <span id="card-validacion-boceto-${ arte.id }">${ estValidacionBoceto.estatus }</span></span>
        <span class="mr-3"><strong class="text-secondary">Confirmación de Proveedor:</strong> <span id="card-confirm-proveedor-${ arte.id }">${ estConfirmacionProveedor.estatus }</span></span>
      `;      

    })
    
  }
  </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('ccs_file'); ?>
<style>
    .set-back {
      position: absolute;
      width: 100%;
      height: 100%;
      z-index: 10;
    }
    .card {
        margin-top: 20px;
        margin-bottom: 20px;
    }
    
    .card-body{
        margin-top: -30px;
    }

    .launch {
      cursor: pointer;
    }
    .filter {
      margin: 10px;
    }

    .form-inline label {
      justify-content: start;
    }

    .more-details {
      font-size: 12px !important;
    }

    .no-result {
      display: none;
    }

    select {
      min-width: 12rem;
    }

    @media (max-width: 520px) {
        
      .status {
          flex-direction: column;
      }
    }

    @media (min-width: 600px) {
      .separator {
        display: none;
      }
    }

</style>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/arte/index.blade.php ENDPATH**/ ?>