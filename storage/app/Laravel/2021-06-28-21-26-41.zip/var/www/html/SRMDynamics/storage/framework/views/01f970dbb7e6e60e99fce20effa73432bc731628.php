<?php $__env->startSection('content'); ?>

<div class="d-flex flex-wrap justify-content-center wrapper-card">
    
    <?php
        $array_user           = array();
        $array_empresa        = array();
        $array_empresa_nombre = array();
    ?>
    <?php $__currentLoopData = $produccionTransitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produccionTransito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php
            $user = $produccionTransito->pivotTable->tarea->usuarios->name;
            $empresa = $produccionTransito->pivotTable->proveedor->pais;
            $nombre_empresa = $produccionTransito->pivotTable->proveedor->nombre;
            array_push($array_empresa, $empresa);
            array_push($array_user, $user);       
            array_push($array_empresa_nombre, $nombre_empresa);       
                
       ?>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php
        $numero = 0;
        $array_user_unico = array_unique($array_user);
        $array_empresa_unico = array_unique($array_empresa);
        $array_empresa_nombre_unuci = array_unique($array_empresa_nombre);
    ?>
    

   
       


    <div class="container">
        <div class="row">      
           
            <div  class="menu_iconos btn btn-sm" data-filter="all">
                Todos
            </div>     
            <?php $__currentLoopData = $array_user_unico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div  class="menu_iconos btn btn-sm" data-filter="<?php echo e($item); ?>">
                <?php echo e($item); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
            <?php $__currentLoopData = $array_empresa_unico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div  class="menu_iconos btn btn-sm" data-filter="<?php echo e($item); ?>">
                <?php echo e($item); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            <?php $__currentLoopData = $array_empresa_nombre_unuci; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div  class="menu_iconos btn btn-sm" data-filter="<?php echo e($item); ?>">
                <?php echo e($item); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
        </div>
     </div>
    <div class="filtro-container d-flex flex-wrap justify-content-betwen ">
       <?php $__currentLoopData = $produccionTransitos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produccionTransito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $contador = 0 ;
        $numero
        ?>
        <?php if($produccionTransito->pivotTable->tarea->usuarios->name == Auth::user()->name || Auth::user()->rol == 'coordinador' || Auth::user()->rol == 'logistica'): ?>
        <div class="card filtr-item w-350 m-5" data-category="<?php echo e($produccionTransito->pivotTable->tarea->usuarios->name); ?>,<?php echo e($produccionTransito->pivotTable->proveedor->pais); ?>,<?php echo e($produccionTransito->pivotTable->proveedor->nombre); ?>">
                  <div class="card-body  m3 p-3 d-flex justify-content-between flex-wrap">
                     <div class="p-3">
                     <h5 class="d-flex align-items-center">
                        <a  <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?>  href="<?php echo e(route('pago-anticipado.index', ['produccionTransitoId' =>  $produccionTransito->id])); ?>"  else  href="#" onclick="deshabilitar(this)" <?php endif; ?>>
                        <strong>Pago Anticipado</strong></a>:
                        <?php if($produccionTransito->pagos_anticipados): ?>
                            <span class="material-icons text-success">
                                done_all
                            </span>
                            <?php echo e($contador++); ?>

                        <?php else: ?>
                            <span class="material-icons text-danger">
                                clear
                            </span>
                        <?php endif; ?>
                     </h5>
                     </div>
                     <?php if($produccionTransito->pagos_anticipados): ?>
                     <div class="p-3">
                     <h5>
                        <strong>Pagado (%)</strong>:
                        100%
                     </h5>
                     </div>
                     <?php endif; ?>
                        <div class="p-3">
                            <h5 class="d-flex">
                              <a  <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?> href="<?php echo e(route('inicio-produccion.index', ['produccionTransitoId' =>  $produccionTransito->id])); ?>"  else { href="#" onclick="deshabilitar(this)" <?php endif; ?>>
                                        <strong>Inicio Producción:</strong></a>:
                                      
                                        <?php if($produccionTransito->inicioProduccion): ?>
                                            <span class="material-icons text-success">
                                                done_all
                                                <?php echo e($contador++); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="material-icons text-danger">
                                                clear
                                            </span>
                
                                        <div class="d-flex text-primary pointer ml-2 align-items-center">
            
                                        <form action="<?php echo e(route('ProduccionTransito.iniciarProd', ['id' => $produccionTransito->id])); ?>" method="POST" style="display: contents;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('put'); ?>
                                            <button class="btn btn-secondary btn-prod text-primary">
                                                <span class="material-icons mr-1">
                                                    security_update_good
                                                </span>
                                                <small class="iniciar-prod font-weight-light">
                                                    Iniciar
            
                                                </small>
                                            </button>
                                        </form>
                                        </div>
                                    <?php endif; ?>
                            </h5>
                        </div>
                    <div class="p-3">
                        <h5>
                           <a  <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador' ): ?> href="<?php echo e(route('pago-balance.index', ['produccionTransitoId' =>  $produccionTransito->id])); ?>"  else { href="#" onclick="deshabilitar(this)" <?php endif; ?>>
                           <strong>Pago de Balance:</strong></a>:
                           <?php if($produccionTransito->pago_balance): ?>
                               <span class="material-icons text-success">
                                   done_all
                                   <?php echo e($contador++); ?>

                                   
                               </span>
       
                           <?php else: ?>
                               <span class="material-icons text-danger">
                                   clear
                               </span>
                           <?php endif; ?>
                        </h5>
                    </div>
    
                       <?php if($produccionTransito->pago_balance): ?>
                       <div class="p-3">    
                        <h5>
                        <strong>Pagado Balance (%)</strong>:
                          90%
                        </h5>
                       </div>
                       <?php endif; ?>
                     <div class="p-3">
                       <h5>
                         <a  <?php if(Auth::user()->rol == 'comprador' || Auth::user()->rol == 'coordinador'): ?> href="<?php echo e(route('fin-produccion.index', ['produccionTransitoId' =>  $produccionTransito->id])); ?>"  else { href="#" onclick="deshabilitar(this)" <?php endif; ?>>
                         <strong>Fin de Producción</strong></a>:
                         <?php if($produccionTransito->finProduccion): ?>
                             <span class="material-icons text-success">
                                 done_all
                                 <?php echo e($contador++); ?>

                             </span>
                         <?php else: ?>
                             <span class="material-icons text-danger">
                                 clear
                             </span>
                         <?php endif; ?>
                        </h5>
                     </div>
                     <div class="p-3">
                        <h5>
                           <a  <?php if(Auth::user()->rol == 'logistica' || Auth::user()->rol == 'coordinador'): ?> href="<?php echo e(route('transito-nacionalizacion.index', ['produccionTransitoId' =>  $produccionTransito->id])); ?>" else { href="#" onclick="deshabilitar(this)" <?php endif; ?>>
                           
                              <strong>Transito Nacionalización</strong>
                           </a>:
                           <?php if($produccionTransito->transitosNacionalizacion): ?>
                               <span class="material-icons text-success">
                                   done_all
                                   <?php echo e($contador++); ?>

                               </span>
       
                           <?php else: ?>
                               <span class="material-icons text-danger">
                                   clear
                               </span>
                           <?php endif; ?>
                        </h5>
                     </div>
                         <?php
                         $disabled = 'disabled';
                         $bgAlert = 'bg-danger';
                         ?>
                         <?php if($contador >= 5): ?>
                         <?php
                         $disabled = '';
                         $bgAlert  = 'bg-success'; 
                         ?>
                     
                         <?php endif; ?>
                        <div class="p-3">
                            <h5 class="py-1 d-flex  justify-content-start align-items-center">  
                                               
                               <span class="form-check d-flex justify-content-start">
                                  <div class="circle <?php echo e($bgAlert); ?> mx-1"></div>
                                  <a href="">
                                      Salida de Puerto Origen :
                                  </a>
                                  
                                      <label class="form-check-label mx-3">
                                        <input class="form-check-input" type="checkbox" value="<?php echo e($produccionTransito->id); ?>" <?php echo e($disabled); ?> <?php echo e($produccionTransito->salida_puero_origen ? 'checked' : ''); ?>>
                                        <span class="form-check-sign">
                                          <span class="check"></span>
                                        </span>
                                      </label>
                                      
                              </span>
                            </h5>   
                        </div>
                

                  </div> 
                <div class="d-flex flex-wrap">
                   <button class="btn btn-secundary  btn-sm" data-toggle="collapse" data-target="#collapseOne<?php echo e($produccionTransito->id); ?>" aria-expanded="true" aria-controls="collapseOne<?php echo e($produccionTransito->id); ?>">
                    Detalle del Proveedor
                   </button>
                   <button class="btn btn-secundary  btn-sm collapsed" data-toggle="collapse" data-target="#collapseTwo<?php echo e($produccionTransito->id); ?>" aria-expanded="false" aria-controls="collapseTwo<?php echo e($produccionTransito->id); ?>">
                     Detalle de Compra
                   </button>
                </div>
                <div id="accordion">
                     <div id="collapseOne<?php echo e($produccionTransito->id); ?>" class="collapse " aria-labelledby="headingOne<?php echo e($produccionTransito->is); ?>" data-parent="#accordion">
                           <div class="card-body d-flex flex-wrap">
                               <h6 class="p-2 border m-1"><strong>Tarea</strong>: <?php echo e($produccionTransito->pivotTable->tarea->nombre); ?></h6>
                               <h6 class="p-2 border m-1"><strong>Proveedor</strong>: <?php echo e($produccionTransito->pivotTable->proveedor->nombre); ?></h6>
                               <h6 class="p-2 border m-1"><strong>Pais</strong> : <?php echo e($produccionTransito->pivotTable->proveedor->pais); ?></h6>
                               <h6 class="p-2 border m-1"><strong>Ciudad</strong> : <?php echo e($produccionTransito->pivotTable->proveedor->ciudad); ?></h6>
                               <h6 class="p-2 border m-1"><strong>Distrito</strong> : <?php echo e($produccionTransito->pivotTable->proveedor->distrito); ?></h6>
                               <h6 class="p-2 border m-1"><strong>Conatacto</strong> : <?php echo e($produccionTransito->pivotTable->proveedor->contacto); ?></h6>   
                               <h6 class="p-2 border m-1"><strong>Télefono</strong> : <?php echo e($produccionTransito->pivotTable->proveedor->telefono); ?></h6>  
                               <h6 class="p-2 border m-1"><strong>Email</strong> : <?php echo e($produccionTransito->pivotTable->proveedor->email); ?></h6>       
                           </div>
                     </div>
                     <div id="collapseTwo<?php echo e($produccionTransito->id); ?>" class="collapse" aria-labelledby="headingTwo<?php echo e($produccionTransito->id); ?>" data-parent="#accordion">
                           <div class="card-body d-flex flex-wrap">
                               <?php $__currentLoopData = $produccionTransito->pivotTable->proveedor->compra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <h6 class="p-2 border m-1"><strong>Orden Compra</strong>: <?php echo e($compra->orden_compra); ?></h6>
                                   <h6 class="p-2 border m-1"><strong>Item</strong>: <?php echo e($compra->item); ?></h6>
                                   <h6 class="p-2 border m-1"><strong>Registro de Salud</strong>: <?php echo e($compra->registro_salud); ?></h6>
                                   <h6 class="p-2 border m-1"><strong>Cantidad PCS</strong>: <?php echo e($compra->cantidad_pcs); ?></h6>
                                   <h6 class="p-2 border m-1"><strong>Total</strong>: <?php echo e($compra->total); ?></h6>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                           </div>
                     </div>
                </div>
        </div>
        <?php endif; ?>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </div>

    <?php if(Session::has('message')): ?>
        <div id="toast" class="toast alert alert-<?php echo e(Session::get('class')); ?> alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('message')); ?>


            <span class="material-icons ml-2">
                done_all
            </span>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('ccs_file'); ?>
    <style>
        
       

        .iniciar-prod {
            margin-left: -5px
        }

        .btn-secondary {
            padding: 0px
        }

        .toast {
            display: flex;
            justify-content: center;
            position: fixed;
            top: 50%;
            left: 10px;
            right: 10px;
            align-items: center;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => {
                if(document.getElementById('toast')) {
                    document.getElementById('toast').style.display = 'none';
                }
            }, 2000);
        });  
        cargarEventListener();

        function cargarEventListener()
        {
            let wrapperCard = document.querySelector('.wrapper-card');            
            wrapperCard.addEventListener('click', function(e){
                if(e.target.classList.contains('form-check-input'))
                {
                    let checkOut = e.target.checked;
                    let csrfToken = document.head.querySelector("[name~=csrf-token][content]").content; 
                    
                    
                    
                    if(checkOut)
                    {
                        let id = e.target.value
                        fetch(`/salida-puerto-origen/${id}`, {
                            method: 'PUT',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': csrfToken
                            }
                        })
                        .then(response => response.json())
                        .then( data => console.log(data) )
                        .catch(e => console.log(e))                      
                    }
                    else{
                        e.target.checked = true

                    }
                }
                
            })
        }

        

    </script>
    
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/js/jquery.filterizr.min.js')); ?>"></script>
<script type="text/javascript">
 $(document).ready(function() 
 {
    if($('.filtro-container').length){
    $('.filtro-container').filterizr();
  }
 })  
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/produccion-transito/index.blade.php ENDPATH**/ ?>