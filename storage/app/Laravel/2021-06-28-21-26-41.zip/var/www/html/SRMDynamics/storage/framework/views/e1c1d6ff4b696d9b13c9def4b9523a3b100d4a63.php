<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-end">
        <a
            class="btn btn-outline-primary btn-round" 
            href="<?php echo e(url()->previous()); ?>"
            data-toggle="tooltip" 
            data-placement="left" 
            title="Atras"
        >
        <span class="material-icons mr-2">
            keyboard_backspace
        </span>
            Atras
        </a>
    </div>

    <h4>Crear una incidencia sobre la Inspección de Carga</h4>

    <form method="POST" action="<?php echo e(route('inspeccion-cargas.store', ['rcdId' => $rcdId])); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-container">

            <div class="form-group mr-3  <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="bmd-label-floating">Titulo</label>
                <input value="<?php echo e(old('titulo')); ?>" autocomplete="off" name="titulo" type="text" class="form-control">
                <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
    
           
            <div class="form-group  <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <label class="bmd-label-floating">Descripción</label>
                <input value="<?php echo e(old('descripcion')); ?>" autocomplete="off" name="descripcion" type="text" class="form-control">
                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback d-block" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

        </div>


        <div class="d-flex justify-content-center mt-3">
            <button class="btn btn-outline-primary btn-round">
                Crear
            </button>
        </div>
        

    </form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

    <style>
        .form-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }

        @media (min-width: 600px) {
            .form-group {
                width: 40%
            }
       }

        @media (max-width: 600px) {
            .form-group {
                width: 100%
            }
        }
    </style>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/inspeccion-carga/create.blade.php ENDPATH**/ ?>