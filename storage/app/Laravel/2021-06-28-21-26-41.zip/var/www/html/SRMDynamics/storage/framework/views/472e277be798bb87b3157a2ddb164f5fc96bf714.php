<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
        <a
            class="btn btn-outline-primary btn-round"
            href="<?php echo e(route('fin-produccion.create', ['id_produccion_transito' => $produccionTransito->id])); ?>"
        >
            <span class="material-icons mr-2">
                add_circle_outline
            </span>
            Crear
        </a>

        <a
            class="btn btn-outline-primary btn-round" 
            href="<?php echo e(url('/produccion-transito')); ?>"
            data-toggle="tooltip" 
            data-placement="left" 
            title="Atras"
        >
            <span class="material-icons mr-2">
                keyboard_backspace
            </span>
            Atras
        </a>
    </div>

    <?php if( count($finProducciones) > 0 ): ?>
        <div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th><strong>ID</strong></th>
                            <th class="th-description">Titulo</th>
                            <th class="th-description">Descripcion</th>
                            <th class="th-description">Fecha</th>
                            <th class="th-description">Usuario</th>    
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $finProducciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finProduccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($finProduccion->id); ?></td>
                                <td class="td-name">
                                    <?php echo e($finProduccion->titulo); ?>

                                </td>
                                <td>
                                    <?php echo e($finProduccion->descripcion); ?>

                                </td>
                                <td>
                                    <?php echo e(date('d-m-Y', strtotime($finProduccion->created_at))); ?>

                                </td>
                                <!--TODO: Configure migrations and model to get and set the user -->
                                <td>
                                    <?php echo e($finProduccion->user->name); ?>

                                </td>

                                <td class="d-flex">
                                    <a
                                        href="<?php echo e(route('fin-produccion.edit', [ 'fin_produccion' => $finProduccion->id, "id_produccion_transito" => $produccionTransito->id])); ?>"
                                        class="btn btn-outline-primary btn-fab btn-fab-mini btn-round"
                                    >
                                        <i class="material-icons">mode_edit</i>
                                    </a>
            
                                    <form action='<?php echo e(route("fin-produccion.destroy", [ 'fin_produccion' => $finProduccion->id, 'id_produccion_transito' => $produccionTransito->id])); ?>' method="POST" style="display: contents;">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-outline-primary btn-fab btn-fab-mini btn-round ml-2"><i class="material-icons">delete</i></button>
                                    </form>
                                </td>
        
                            </tr>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>

        </div>

    <?php else: ?>
        
        <?php echo $__env->make('ui.nada-para-mostrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


    <?php if(Session::has('message')): ?>
        <div id="toast" class="toast alert alert-<?php echo e(Session::get('class')); ?> alert-dismissible fade show" role="alert">
            <?php echo e(Session::get('message')); ?>


            <span class="material-icons ml-2">
                done_all
            </span>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <style>
        .toast {
            display: flex;
            justify-content: center;
            position: fixed;
            top: 50%;
            left: 10px;
            right: 10px;
            align-items: center;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/fin-produccion/index.blade.php ENDPATH**/ ?>