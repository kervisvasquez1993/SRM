<?php $__env->startSection('content'); ?>

<?php $__currentLoopData = Auth::user()->tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startComponent('componentes.cardGeneral'); ?>
    <?php $__env->slot('titulo'); ?>
        <span><?php echo e($tarea->nombre); ?></span> 
        <span><?php echo e($tarea->proveedor->count()); ?> proveedores</span>
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('bodyCard'); ?>
       <?php echo e($tarea->descripcion); ?>

    <?php $__env->endSlot(); ?>

    <?php $__env->slot('contenidoFooter'); ?>

            <div class="stats">
              <i class="material-icons">access_time</i> Finalización : <?php echo e(date('d-M-Y', strtotime($tarea->fecha_fin))); ?>

            </div>
            <div>
              <?php if(Auth::user()->rol == 'comprador'): ?>
                <a href="#" type="button" 
                            class="btn btn-sm btn-outline-warning btn-round" 
                            data-id_tarea=<?php echo e($tarea->id); ?>

                            data-toggle="modal" data-target="#abrirmodalEditar"
                        >
                       Agregar Empresa
                </a>
                <?php endif; ?>
               <a href="<?php echo e(route('tareas.show', ['tarea' => $tarea->id])); ?>" class="btn btn-sm btn-outline-primary btn-round">Ver Detalle</a>
         
    </div>

    <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f)): ?>
<?php $component = $__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f; ?>
<?php unset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->startComponent('componentes.formularioModalEdit'); ?>
  <?php $__env->slot('titleForm'); ?>
      <h4>Añadir Nueva Empresa</h4>
  <?php $__env->endSlot(); ?>
  <?php $__env->slot('route'); ?>
      <?php echo e(route('proveedores.store')); ?>

  <?php $__env->endSlot(); ?>
  <?php $__env->slot('method'); ?>
      post
  <?php $__env->endSlot(); ?>

  <?php $__env->slot('BodyForm'); ?>
  
      <input type="hidden" id="id_tarea" name="id_tarea" value="">
      <?php echo $__env->make('inicio.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php $__env->endSlot(); ?>
<?php if (isset($__componentOriginald1f532309cc9192b1ca97ef42a36af59e0eff7c1)): ?>
<?php $component = $__componentOriginald1f532309cc9192b1ca97ef42a36af59e0eff7c1; ?>
<?php unset($__componentOriginald1f532309cc9192b1ca97ef42a36af59e0eff7c1); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/inicio/index.blade.php ENDPATH**/ ?>