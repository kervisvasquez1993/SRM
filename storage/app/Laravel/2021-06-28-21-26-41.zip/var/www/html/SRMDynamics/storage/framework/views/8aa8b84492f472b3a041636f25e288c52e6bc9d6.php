<?php $__env->startSection('content'); ?>

    <form class="form p-4" method="POST" action="<?php echo e(route('inicio-produccion.store', ['id_produccion_transito' => $produccionTransito->id])); ?>">
        <?php echo csrf_field(); ?>
    
        <h3 class="ml-4 mb-3">Crea un incidencia relacionada con el inicio de producción</h3>  

        <div class="form-group titulo-input  <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label class="bmd-label-floating">Titulo</label>
            <input value="<?php echo e(old('titulo')); ?>" autocomplete="off" name="titulo" type="text" class="form-control">
            <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback d-block" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group titulo-input  <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
            <label class="bmd-label-floating">Descripción</label>
            <input value="<?php echo e(old('descripcion')); ?>" autocomplete="off" name="descripcion" type="text" class="form-control">
            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback d-block" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="d-flex justify-content-center mt-3">
            <button class="btn btn-outline-primary btn-round">
                Crear
            </button>
        </div>
    </form>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <style>

        .form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        @media( min-width: 700px) {
            .titulo-input {
                width: 50%;
            }
        }

    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/inicio-produccion/create.blade.php ENDPATH**/ ?>