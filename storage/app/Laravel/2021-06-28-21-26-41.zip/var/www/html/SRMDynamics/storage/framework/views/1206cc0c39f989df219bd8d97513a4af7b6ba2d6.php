<div class="col-lg-3 mb-4">
   
   <h3 class="mt-2">Categories</h3>
   <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="form-check">
           <input class="form-check-input" type="checkbox" id="category<?php echo e($index); ?>" value="<?php echo e($category->id); ?>" wire:model="selected.categories">
           <label class="form-check-label" for="category<?php echo e($index); ?>">
               <?php echo e($category); ?>

           </label>
       </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   <h3 class="mt-2">Manufacturers</h3>
   <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="form-check">
           <input class="form-check-input" type="checkbox" id="manufacturer<?php echo e($index); ?>" value="<?php echo e($manufacturer->id); ?>" wire:model="selected.manufacturers">
           <label class="form-check-label" for="manufacturer<?php echo e($index); ?>">
               <?php echo e($manufacturer); ?>

           </label>
       </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div> <?php /**PATH /var/www/html/SRMDynamics/resources/views/livewire/sidebar-filter.blade.php ENDPATH**/ ?>