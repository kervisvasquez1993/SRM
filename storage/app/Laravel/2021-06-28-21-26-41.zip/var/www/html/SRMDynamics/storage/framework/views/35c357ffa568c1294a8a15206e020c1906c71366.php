<div class="card">
    <div class="card-header">
        <div class="card-text">
            <h5 class="card-title d-flex justify-content-between w-100"><?php echo e($titulo); ?></h5>
        </div>
        <hr>
    </div>
    <div class="card-body">
        <?php echo e($bodyCard); ?>

    </div>
    <div class="card-footer">
        <div class="d-flex justify-content-between w-100 flex-wrap">
            <?php echo e($contenidoFooter); ?>

        </div>
    </div>
</div>
<?php /**PATH /var/www/html/SRMDynamics/resources/views/componentes/cardGeneral.blade.php ENDPATH**/ ?>