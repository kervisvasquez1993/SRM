<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    SRM Dynamics
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="<?php echo e(asset('assets/css/material-dashboard.css?v=2.1.2')); ?>" rel="stylesheet" />
  <?php echo $__env->yieldContent('ccs_file'); ?>
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="<?php echo e(asset('assets/demo/demo.css')); ?>" rel="stylesheet" />
  <link href="<?php echo e(asset('util/css/style.css')); ?>" rel="stylesheet" />

  <?php echo $__env->yieldContent('css'); ?>
  <!-- Scripts -->
  
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

  <?php echo $__env->yieldContent('script'); ?>

  <!-- Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  <?php echo $__env->make('util.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>
<div id="app">
  <div class="wrapper">
  
    <div class="main-panel">
      
        <?php echo $__env->yieldContent('content'); ?>
       <?php echo $__env->yieldContent('footer'); ?> 
    </div>
  </div>
</div>

  <!--   Core JS Files   -->
  <script src="<?php echo e(asset('assets/js/core/jquery.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/core/bootstrap-material-design.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/js/plugins/moment.min.js')); ?>"></script>
. <!--	Plugin for Select, full documentation here: http://silviomoreto.github.io/bootstrap-select -->
  <script src="<?php echo e(asset('assets/js/plugins/bootstrap-selectpicker.js')); ?>"></script>
  <!--  Plugin for the DateTimePicker, full documentation here: https://eonasdan.github.io/bootstrap-datetimepicker/ -->
  <script src="<?php echo e(asset('assets/js/plugins/bootstrap-datetimepicker.min.js')); ?>"></script>
  <!--  DataTables.net Plugin, full documentation here: https://datatables.net/  -->
  <script src="<?php echo e(asset('assets/js/material-dashboard.js')); ?>" type="text/javascript"></script>
  <!-- Material Dashboard DEMO methods, don't include it in your project! -->
  <script>
    $(document).ready(function() {

      if ($('#abrirmodalEditar'))
      {
         $('#abrirmodalEditar').on('show.bs.modal', function (event) {
           var button = $(event.relatedTarget) 
           var nombre_modal_tarea = button.data('tarea')
           var nombre_modal_comprador = button.data('comprador')
           var nombre_modal_descripcion = button.data('descripcion')
           var nombre_modal_fecha_fin = button.data('fecha_fin')
           var nombre_modal_user_name = button.data('user_name')
           var id_categoria = button.data('id_tarea')
           /* var descripcion_modal_editar = button.data('descripcion')
            */
           var modal = $(this)
          
           // modal.find('.modal-title').text('New message to ' + recipient)
           modal.find('.modal-body #id_tarea').val(id_categoria);
           modal.find('.modal-body #user_id').val(nombre_modal_user_name);
           modal.find('.modal-body #nombre').val(nombre_modal_tarea);
           modal.find('.modal-body #descripcion').val(nombre_modal_descripcion);
           modal.find('.modal-body #fecha_fin').val(nombre_modal_fecha_fin);
   
            
           /* modal.find('.modal-body #descripcion').val(descripcion_modal_editar); */
           
           })
      }

      if ($('#abrirmodalEditarProveedor'))
      {
         $('#abrirmodalEditarProveedor').on('show.bs.modal', function (event) {
           var button = $(event.relatedTarget) 
           var nombre_modal_tarea = button.data('tarea')
           var nombre_modal_comprador = button.data('comprador')
           var nombre_modal_descripcion = button.data('descripcion')
           var nombre_modal_fecha_fin = button.data('fecha_fin')
           var nombre_modal_user_name = button.data('user_name')
           var id_categoria = button.data('id_tarea')
           /* var descripcion_modal_editar = button.data('descripcion')
            */
           var modal = $(this)
          
           // modal.find('.modal-title').text('New message to ' + recipient)
           modal.find('.modal-body #id_tarea').val(id_categoria);
           modal.find('.modal-body #user_id').val(nombre_modal_user_name);
           modal.find('.modal-body #nombre').val(nombre_modal_tarea);
           modal.find('.modal-body #descripcion').val(nombre_modal_descripcion);
           modal.find('.modal-body #fecha_fin').val(nombre_modal_fecha_fin);
   
            
           /* modal.find('.modal-body #descripcion').val(descripcion_modal_editar); */
           
           })
      }

      $().ready(function() {
        $sidebar = $('.sidebar');

        $sidebar_img_container = $sidebar.find('.sidebar-background');

        $full_page = $('.full-page');

        $sidebar_responsive = $('body > .navbar-collapse');

        window_width = $(window).width();

        fixed_plugin_open = $('.sidebar .sidebar-wrapper .nav li.active a p').html();

        if (window_width > 767 && fixed_plugin_open == 'Dashboard') {
          if ($('.fixed-plugin .dropdown').hasClass('show-dropdown')) {
            $('.fixed-plugin .dropdown').addClass('open');
          }

        }

        $('.fixed-plugin a').click(function(event) {
          // Alex if we click on switch, stop propagation of the event, so the dropdown will not be hide, otherwise we set the  section active
          if ($(this).hasClass('switch-trigger')) {
            if (event.stopPropagation) {
              event.stopPropagation();
            } else if (window.event) {
              window.event.cancelBubble = true;
            }
          }
        });

        $('.fixed-plugin .active-color span').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-color', new_color);
          }

          if ($full_page.length != 0) {
            $full_page.attr('filter-color', new_color);
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.attr('data-color', new_color);
          }
        });

        $('.fixed-plugin .background-color .badge').click(function() {
          $(this).siblings().removeClass('active');
          $(this).addClass('active');

          var new_color = $(this).data('background-color');

          if ($sidebar.length != 0) {
            $sidebar.attr('data-background-color', new_color);
          }
        });

        $('.fixed-plugin .img-holder').click(function() {
          $full_page_background = $('.full-page-background');

          $(this).parent('li').siblings().removeClass('active');
          $(this).parent('li').addClass('active');


          var new_image = $(this).find("img").attr('src');

          if ($sidebar_img_container.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            $sidebar_img_container.fadeOut('fast', function() {
              $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
              $sidebar_img_container.fadeIn('fast');
            });
          }

          if ($full_page_background.length != 0 && $('.switch-sidebar-image input:checked').length != 0) {
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $full_page_background.fadeOut('fast', function() {
              $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
              $full_page_background.fadeIn('fast');
            });
          }

          if ($('.switch-sidebar-image input:checked').length == 0) {
            var new_image = $('.fixed-plugin li.active .img-holder').find("img").attr('src');
            var new_image_full_page = $('.fixed-plugin li.active .img-holder').find('img').data('src');

            $sidebar_img_container.css('background-image', 'url("' + new_image + '")');
            $full_page_background.css('background-image', 'url("' + new_image_full_page + '")');
          }

          if ($sidebar_responsive.length != 0) {
            $sidebar_responsive.css('background-image', 'url("' + new_image + '")');
          }
        });

        $('.switch-sidebar-image input').change(function() {
          $full_page_background = $('.full-page-background');

          $input = $(this);

          if ($input.is(':checked')) {
            if ($sidebar_img_container.length != 0) {
              $sidebar_img_container.fadeIn('fast');
              $sidebar.attr('data-image', '#');
            }

            if ($full_page_background.length != 0) {
              $full_page_background.fadeIn('fast');
              $full_page.attr('data-image', '#');
            }

            background_image = true;
          } else {
            if ($sidebar_img_container.length != 0) {
              $sidebar.removeAttr('data-image');
              $sidebar_img_container.fadeOut('fast');
            }

            if ($full_page_background.length != 0) {
              $full_page.removeAttr('data-image', '#');
              $full_page_background.fadeOut('fast');
            }

            background_image = false;
          }
        });

        $('.switch-sidebar-mini input').change(function() {
          $body = $('body');

          $input = $(this);

          if (md.misc.sidebar_mini_active == true) {
            $('body').removeClass('sidebar-mini');
            md.misc.sidebar_mini_active = false;

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar();

          } else {

            $('.sidebar .sidebar-wrapper, .main-panel').perfectScrollbar('destroy');

            setTimeout(function() {
              $('body').addClass('sidebar-mini');

              md.misc.sidebar_mini_active = true;
            }, 300);
          }

          // we simulate the window Resize so the charts will get updated in realtime.
          var simulateWindowResize = setInterval(function() {
            window.dispatchEvent(new Event('resize'));
          }, 180);

          // we stop the simulation of Window Resize after the animations are completed
          setTimeout(function() {
            clearInterval(simulateWindowResize);
          }, 1000);

        });
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      // Javascript method's body can be found in assets/js/demos.js
      md.initDashboardPageCharts();

    });
  </script>
  <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH /var/www/html/SRMDynamics/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>