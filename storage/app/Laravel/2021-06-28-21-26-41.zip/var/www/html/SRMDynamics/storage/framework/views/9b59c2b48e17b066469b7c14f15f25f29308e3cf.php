<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('ui.botones-incidencia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if( count($validacionBocetos) > 0 ): ?>
        
        <?php echo $__env->make('ui.incidencias-table', array('incidencias' => $validacionBocetos, 'path' => '/validacion-bocetos'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php else: ?>
        
        <?php echo $__env->make('ui.nada-para-mostrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php echo $__env->make(
        'ui.modal-incidencia', 
        array(
            'modalTitle' => 'Crea una incidencia relacionada con la validación del boceto',
            'arte_id' => $arte->id,
            'path' => '/validacion-bocetos'
        )
    , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <?php echo $__env->make('util.incidencias-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/validacion-boceto/index.blade.php ENDPATH**/ ?>