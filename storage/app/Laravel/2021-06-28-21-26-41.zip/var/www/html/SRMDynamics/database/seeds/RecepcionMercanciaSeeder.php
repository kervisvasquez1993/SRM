<?php

use Illuminate\Database\Seeder;

class RecepcionMercanciaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       
    }
}
