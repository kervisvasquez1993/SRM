<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-wrap justify-content-center">
        <?php $__currentLoopData = $recepcionReclamoDevolucion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rcd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card m-3">

                <div class="card-header d-inline-flex justify-content-around flex-wrap">
                    <h4><strong>Tarea</strong>: <?php echo e($rcd->ProduccionTransito->pivotTable->tarea->nombre); ?></h4>
                    <h4><strong>Proveedor</strong>: <?php echo e($rcd->ProduccionTransito->pivotTable->proveedor->nombre); ?></h4>
                    <h4><strong>Pais</strong>: <?php echo e($rcd->ProduccionTransito->pivotTable->proveedor->pais); ?></h4>
                    <h4><strong>Ciudad</strong>: <?php echo e($rcd->ProduccionTransito->pivotTable->proveedor->ciudad); ?></h4>
                    <h4><strong>Provincia</strong>: <?php echo e($rcd->ProduccionTransito->pivotTable->proveedor->distrito); ?></h4>
                    <?php if($rcd->ProduccionTransito->pivotTable->proveedor->distrito): ?>
                        <h4><strong>Distrito</strong>: <?php echo e($rcd->ProduccionTransito->pivotTable->proveedor->distrito); ?></h4>
                    <?php endif; ?>
                </div>

                <div class="card-body d-flex justify-content-between">
                    <h5 class="d-flex align-items-center">
                        <a href="<?php echo e(route('recepcion-mercancias.index', ['rcdId' => $rcd->id])); ?>">
                            <strong>
                                Recepción Mercancía
                            </strong>
                        </a>: 

                        <?php if($rcd->recepcionMercancia): ?>
                            <span class="material-icons text-success">
                                done_all
                            </span>

                        <?php else: ?>
                            <span class="material-icons text-danger">
                                clear
                            </span>
                        <?php endif; ?>
                    </h5>

                    <h5 class="d-flex align-items-center">
                        <a href="<?php echo e(route('inspeccion-cargas.index', ['rcdId' => $rcd->id])); ?>">
                            <strong>
                                Inspección de Carga
                            </strong>
                        </a>: 
                        <?php if($rcd->inspeccionCarga): ?>
                            <span class="material-icons text-success">
                                done_all
                            </span>

                        <?php else: ?>
                            <span class="material-icons text-danger">
                                clear
                            </span>
                        <?php endif; ?>
                    </h5>

                    <h5 class="d-flex align-items-center">
                        <a href="<?php echo e(route('reclamo-devoluciones.index', ['rcdId' => $rcd->id])); ?>">
                            <strong>
                                Reclamos Devoluciones
                            </strong>
                        </a>: 
                        
                        <?php if($rcd->reclamoDevolucion): ?>
                            <span class="material-icons text-success">
                                done_all
                            </span>

                        <?php else: ?>
                            <span class="material-icons text-danger">
                                clear
                            </span>
                        <?php endif; ?>
                    </h5>

                    

                    

                </div>
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ccs_file'); ?>
    <style>
        .btn-secondary {
            padding: 0px
        }

        .toast {
            display: flex;
            justify-content: center;
            position: fixed;
            top: 50%;
            left: 10px;
            right: 10px;
            align-items: center;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/reclamos-devoluciones/index.blade.php ENDPATH**/ ?>