<?php $__env->startSection('content'); ?>

    
    <?php echo $__env->make('ui.botones-incidencia', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if( count( $confirmacionProveedores ) > 0 ): ?>
        
        <?php echo $__env->make('ui.incidencias-table', array('incidencias' => $confirmacionProveedores, 'path' => '/confirmacion-proveedor'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php else: ?>
        
        <?php echo $__env->make('ui.nada-para-mostrar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    
    <?php echo $__env->make(
        'ui.modal-incidencia', 
        array(
            'modalTitle' => 'Crea una incidencia relacionada con la Confirmación de Proveedor',
            'arte_id' => $arte->id,
            'path' => '/confirmacion-proveedor'
        )
    , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('util.incidencias-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/confirmacion-proveedor/index.blade.php ENDPATH**/ ?>