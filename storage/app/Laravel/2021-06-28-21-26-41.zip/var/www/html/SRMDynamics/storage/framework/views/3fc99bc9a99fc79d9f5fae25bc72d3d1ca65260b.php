<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between">
       
       <div>
            
            <a
                class="btn btn-sm btn-outline-primary btn-round"
                type="button"
                href="<?php echo e(route('compras.create', ['id_proveedor' => $id_proveedor] )); ?>"
            >
              <span class="material-icons mr-2 text-primary">
                add_circle_outline
              </span>
              <span class="text-primary">
                  Añadir Factura de Compra
              </span>
            </a>
       </div>
       <?php echo $__env->make('ui.previous', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    </div>

    <h4><strong>Proveedor</strong>: <?php echo e($proveedor->nombre); ?></h4>
    
    <div id="accordion" role="tablist">


        <?php $__currentLoopData = $proveedor->compra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
  
                <div class="card-header d-flex justify-content-around flex-wrap">
                    <h4><strong>Nombre</strong>: <?php echo e($producto->product_name); ?></h4>
                    <h4><strong>Marca</strong>: <?php echo e($producto->brand); ?></h4>
                    <h4><strong>Código</strong>: <?php echo e($producto->product_code); ?></h4>
                    <h4><strong>Código HS</strong>: <?php echo e($producto->hs_code); ?></h4>
                </div>

                <div class="card-body">
                    <div class="d-flex flex-wrap">
                        <p><strong>Descripción</strong>: <?php echo e($producto->description); ?></p>
                    </div>

                    <div class="d-flex flex-column justify-content-between flex-sm-row">

                        <div class="d-flex flex-column">
                            <h5><strong>Vida útil (meses)</strong>: <?php echo e($producto->shelf_life); ?></h5>
                            <h5><strong>Total de piezas</strong>: <?php echo e($producto->total_pcs); ?></h5>
                            <h5><strong>Piezas empaque unitario</strong>: <?php echo e($producto->pcs_unit); ?></h5>
                            <h5><strong>Piezas carton (cm)</strong>: <?php echo e($producto->pcs_ctn); ?></h5>
                            <h5><strong>Largo Carton (cm)</strong>: <?php echo e($producto->ctn_packing_size_l); ?></h5>
                        </div>

                        <div class="d-flex flex-column">
                            <h5><strong>Alto Carton (cm)</strong>: <?php echo e($producto->ctn_packing_size_h); ?></h5>
                            <h5><strong>Ancho Carton (cm)</strong>: <?php echo e($producto->ctn_packing_size_w); ?></h5>
                            <h5><strong>CBM</strong>: <?php echo e($producto->cbm); ?></h5>
                            <h5><strong>Peso Neto (kg)</strong>: <?php echo e($producto->n_w_ctn); ?></h5>
                            <h5><strong>Peso Bruto (kg)</strong>: <?php echo e($producto->g_w_ctn); ?></h5>
                        </div>

                        <div class="d-flex flex-column">
                            <h5><strong>Total CBM</strong>: <?php echo e($producto->total_cbm); ?></h5>
                            <h5><strong>Total Peso Neto (kg)</strong>: <?php echo e($producto->total_n_w); ?></h5>
                            <h5><strong>Total Peso Bruto (kg)</strong>: <?php echo e($producto->total_g_w); ?></h5>
                            <h5><strong>Total CTN</strong>: <?php echo e($producto->total_ctn); ?></h5>
                            <h5><strong>Corregido Total PCS</strong>: <?php echo e($producto->corregido_total_pcs); ?></h5>
                        </div>

                    </div>
                </div>

                <div class="d-flex justify-content-end">
                    <a
                         class="btn btn-outline-primary btn-fab btn-fab-mini btn-round mr-2 mb-2"
                         type="button"
                         href="<?php echo e(route('productos.edit', ['producto' => $producto->id ] )); ?>" 
                     >
                       <span class="material-icons">
                         edit
                       </span>
                       <span class="text-primary">
                       </span>
                     </a>
                 </div>
            </div>
            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/compras/index.blade.php ENDPATH**/ ?>