<?php $__env->startSection('content'); ?>
    <?php if(Auth::user()->rol == 'coordinador'): ?>
        <div class="container-fluid">
            <button class="btn btn-sm btn-outline-primary btn-round" type="button" data-toggle="modal"
                data-target="#abrirmodal">
                <i class="fa fa-plus fa-2x"></i>&nbsp;&nbsp;Agregar Tarea
            </button>
        </div>
    <?php endif; ?>

    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__env->startComponent('componentes.cardGeneral'); ?>
            <?php $__env->slot('titulo'); ?>
                <span class="tarea d-flex align-items-center">
                    <span class="circle mr-4" data-circulo data-fecha-fin="<?php echo e($tarea->fecha_fin); ?>" data-created-at="<?php echo e($tarea->created_at); ?>"></span>
                    
                    Tarea: <?php echo e($tarea->nombre); ?>

                </span>
                <span>Comprador : <?php echo e($tarea->usuarios->name); ?></span>
                
            <?php $__env->endSlot(); ?>

            <?php $__env->slot('fechaFin'); ?>
                //TODO: eliminar este codigo si no se usa en nada
                <?php echo e(date('d-M-Y', strtotime($tarea->fecha_fin))); ?>

            <?php $__env->endSlot(); ?>

            <?php $__env->slot('bodyCard'); ?>
                <?php echo e($tarea->descripcion); ?>

            <?php $__env->endSlot(); ?>

            <?php $__env->slot('contenidoFooter'); ?>
                <div class="stats">
                    <?php
                        $fecha_asignada = $date::parse(date('d-M-Y', strtotime($tarea->fecha_fin)));
                        $fecha_restantes = $fecha_asignada->diffInDays($date::now());

                    ?>

                    <i class="material-icons">access_time</i> Finalización : <?php echo e(date('d-M-Y', strtotime($tarea->fecha_fin))); ?>.
                    Días Restantes: <?php echo e($fecha_restantes); ?> Días
                </div>

                <div>
                    <?php if(Auth::user()->rol == 'coordinador'): ?>
                        <a href="#" type="button" class="btn btn-sm btn-outline-warning btn-round "
                            data-id_tarea="<?php echo e($tarea->id); ?>" data-tarea="<?php echo e($tarea->nombre); ?>"
                            data-user_name=<?php echo e($tarea->user_id); ?> data-fecha_fin="<?php echo e(date('Y-m-d', strtotime($tarea->fecha_fin))); ?>"
                            data-descripcion="<?php echo e($tarea->descripcion); ?>" data-toggle="modal" data-target="#abrirmodalEditar">
                            Editar
                        </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('tareas.show', ['tarea' => $tarea->id])); ?>"
                        class="btn btn-sm btn-outline-success btn-round">Ver Detalle</a>
                </div>
            <?php $__env->endSlot(); ?>
        <?php if (isset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f)): ?>
<?php $component = $__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f; ?>
<?php unset($__componentOriginalc563a3dcfdef2434811ca2ea53e55128ca0ac63f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="modal fade" id="abrirmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-primary modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">

                    <h4 class="modal-title">Agregar Nueva Tarea</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('tareas.store')); ?>" method="post" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <?php echo $__env->make('task.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

    <!--Inicio del modal actualizar-->
    <div class="modal fade" id="abrirmodalEditar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
        style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-primary modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Actualizar Tareas </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="" method="post" class="form-horizontal">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" id="id_tarea" name="id_tarea" value="">
                        <?php echo $__env->make('task.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </form>
                </div>

            </div>
            <!-- /.modal-content -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.dashboar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/SRMDynamics/resources/views/task/index.blade.php ENDPATH**/ ?>